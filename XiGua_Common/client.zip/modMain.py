# coding=utf-8
from mod.common.mod import Mod

import mod.client.extraClientApi as clientApi
@Mod.Binding(name="neteaseShop", version="0.0.1")
class XiGua_client(object):
    @Mod.InitClient()
    def clientInit(self):
        clientApi.RegisterSystem("Minecraft", "newNeteaseShopClientSystem", "client.neteaseSystem.newNeteaseShopClientSystem.NewNeteaseShopClientSystem")

