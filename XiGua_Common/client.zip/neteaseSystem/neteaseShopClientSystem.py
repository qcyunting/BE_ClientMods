# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/neteaseShopClientSystem.py
import time, mod.client.extraClientApi as clientApi
from mod_log import engine_logger as logger
ClientSystem = clientApi.GetClientSystemCls()
from client.neteaseSystem.neteaseShopCache import ItemShopCache
import network_proxy
from client.neteaseSystem.neteaseBaseShopClientSystem import NeteaseBaseShopClientSystem
import client.neteaseSystem.ui.neteaseShopUIMgr as neteaseShopUIMgr, client.neteaseSystem.ui.neteaseShopUIDef as uiDef

class neteaseShopClientSystem(NeteaseBaseShopClientSystem):

    def __init__(self, namespace, systemName):
        NeteaseBaseShopClientSystem.__init__(self, namespace, systemName)
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'UiInitFinished', self, self.OnUiInitFinished)
        self.ListenForEvent('neteaseShop', 'neteaseShopDev', 'serverReadyEvent', self, self.OnServerReady)
        self.ListenForEvent('neteaseShop', 'neteaseShopDev', 'ShowHintEvent', self, self.OnShowHint)
        self.ListenForEvent('neteaseShop', 'neteaseShopDev', 'OpenShopEvent', self, self.OnOpenShop)
        self.ListenForEvent('neteaseShop', 'neteaseShopDev', 'CloseShopEvent', self, self.OnCloseShop)
        self.ListenForEvent('neteaseShop', 'neteaseShopDev', 'OpenRecoItemEvent', self, self.OnOpenRecoItem)
        self.ListenForEvent('neteaseShop', 'neteaseShopDev', 'CloseRecoItemEvent', self, self.OnCloseRecoItem)
        self.ListenForEvent('neteaseShop', 'neteaseShopDev', 'ShipItemResultEvent', self, self.OnShipItemResult)
        self.ListenForEngine(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'ScreenSizeChangedClientEvent', self, self.OnScreenSizeChanged)
        self.UiDef = uiDef.UIDef
        self.UiData = uiDef.UIData
        return

    def Destroy(self):
        self.mHasDestroy = True
        self.StopBuyTimer()
        return

    def GetShopCache(self):
        return self.mShopCache

    def OnBackFromRn(self, routeName):
        print ('OnBackFromRn routeName={}').format(routeName)
        self.mShopCache.GetMoneyData(True)
        return

    def OnUiInitFinished(self, args):
        self.mUIMgr.Init(self, self.UiData, 'neteaseShop', 'neteaseShopBeh')
        self.NotifyToServer('clientEnterEvent', {'playerId': (clientApi.GetLocalPlayerId())})
        return

    def OnServerReady(self, data):
        print 'OnServerReady', data
        self.mGameId = data['gameId']
        self.mIsTestServer = data['isTestServer']
        self.mCacheTime = data['cacheTime']
        self.mUid = data['uid']
        self.mPlatformUid = data['platformUid']
        self.mUseCustomShop = data['useCustomShop']
        self.mShopCache = ItemShopCache(self, self.mGameId, self.mCacheTime)
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopDesk)
        if ui:
            if self.mUseCustomShop:
                ui.ChangeScreenVisible(True)
                if clientApi.GetPlatform() != 0:
                    clientApi.HideNeteaseStoreGui(True)
            else:
                ui.ChangeScreenVisible(False)
                if clientApi.GetPlatform() != 0:
                    clientApi.HideNeteaseStoreGui(False)
        return

    def StartForceShipItem(self):
        eventData = {'playerId': (clientApi.GetLocalPlayerId())}
        self.NotifyToServer('clientForceShipEvent', eventData)
        self.mWaitingShipItem = True
        return

    def OnShipItemResult(self, data):
        if not self.mWaitingShipItem:
            return
        self.mWaitingShipItem = False
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopFlying)
        shipItemList = data['shipItemList']
        if not shipItemList:
            ui.ShowOne('未查询到商品到账')
            return
        for itemId in shipItemList:
            itemDetailCache = self.mShopCache.GetItemDetail(itemId)
            if not itemDetailCache:
                continue
            itemName = itemDetailCache.mData.get('name', '')
            if not itemName:
                continue
            ui.ShowTwo(itemName, '已到账成功')

        return

    def OnScreenSizeChanged(self, args):
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopMain)
        if ui:
            ui.OnScreenSizeChange()
        return

    def StartBuyItem(self, alreadyBuy, itemId, itemNum=1):
        eventData = {'playerId': (clientApi.GetLocalPlayerId()), 
           'uid': (self.mUid), 
           'platformUid': (self.mPlatformUid), 
           'itemId': itemId, 
           'cancel': False, 
           'reason': ''}
        self.BroadcastEvent('PlayerTryBuyItemEvent', eventData)
        if eventData['cancel']:
            logger.info('PlayerTryBuyItemEvent cancel by event callback')
            if eventData['reason']:
                reason = eventData['reason']
            else:
                reason = '发货中断，无法购买该商品'
            self.ShowConfirmPop('提示', reason)
            return

        def OnBuyRequestSuc(data):
            self.OnBuyRequestSuc(alreadyBuy, itemId, data)
            return

        def queryFunc():
            network_proxy.store_buy_item(itemId, itemNum, 2, OnBuyRequestSuc, self.OnBuyRequestFail)
            print ('store_buy_item start itemId={} itemNum={}').format(itemId, itemNum)
            return

        self.StartShopQuery(queryFunc)
        self.ShowBuyItemWaiting()
        return

    def OnQueryOrderSuc(self, alreadyBuy, itemId, orderId, buyType, repeat, data):
        if data['code'] != 0:
            print ('OnQueryOrderSuc but code error data={}').format(data)
            self.OnQueryOrderFail(alreadyBuy, itemId, orderId, buyType, repeat, data['message'])
            return
        if self.FinishShopQuery():
            return
        print ('OnQueryOrderSuc itemId={}').format(itemId)
        self.HideBuyItemWaiting()
        self.ShowBuySuccess()
        eventData = {'playerId': (clientApi.GetLocalPlayerId()), 
           'uid': (self.mUid), 
           'platformUid': (self.mPlatformUid), 
           'itemId': itemId, 
           'alreadyBuy': alreadyBuy}
        self.BroadcastEvent('BuyItemPaySuccessEvent', eventData)
        self.NotifyToServer('clientBuyItemPaySuccessEvent', {'playerId': (clientApi.GetLocalPlayerId())})
        self.mShopCache.GetItemDetail(itemId, True)
        self.mShopCache.GetMoneyData(True)
        return

    def Destroy(self):
        self.UnListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'UiInitFinished', self, self.OnUiInitFinished)
        self.UnListenForEvent('neteaseShop', 'neteaseShopDev', 'serverReadyEvent', self, self.OnServerReady)
        self.UnListenForEvent('neteaseShop', 'neteaseShopDev', 'ShowHintEvent', self, self.OnShowHint)
        self.UnListenForEvent('neteaseShop', 'neteaseShopDev', 'OpenShopEvent', self, self.OnOpenShop)
        self.UnListenForEvent('neteaseShop', 'neteaseShopDev', 'CloseShopEvent', self, self.OnCloseShop)
        self.UnListenForEvent('neteaseShop', 'neteaseShopDev', 'OpenRecoItemEvent', self, self.OnOpenRecoItem)
        self.UnListenForEvent('neteaseShop', 'neteaseShopDev', 'CloseRecoItemEvent', self, self.OnCloseRecoItem)
        self.UnListenForEvent('neteaseShop', 'neteaseShopDev', 'ShipItemResultEvent', self, self.OnShipItemResult)
        self.UnListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'ScreenSizeChangedClientEvent', self, self.OnScreenSizeChanged)
        return


def StartBuyItem_furtureVersion():
    return


return
