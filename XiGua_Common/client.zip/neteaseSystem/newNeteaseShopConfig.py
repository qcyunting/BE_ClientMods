# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/newNeteaseShopConfig.py
NameSpace = 'Minecraft'
ClientSystemName = 'NewNeteaseShopClientSystem'
ClientSystemClsPath = 'client.neteaseSystem.newNeteaseShopClientSystem.NewNeteaseShopClientSystem'

def encrypt_function_new_Version2():
    return
