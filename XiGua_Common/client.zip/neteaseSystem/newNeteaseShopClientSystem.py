# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/newNeteaseShopClientSystem.py
import time, mod.client.extraClientApi as clientApi
from mod_log import engine_logger as logger
ClientSystem = clientApi.GetClientSystemCls()
from client.neteaseSystem.neteaseShopCache import ItemShopCache
import network_proxy, mc_game_ctrl
from common.network import defaultrpc as rpc
from client.neteaseSystem.neteaseBaseShopClientSystem import NeteaseBaseShopClientSystem
from common.system.systemRegister import server
import common.system.eventConf as conf, client.neteaseSystem.ui.neteaseShopUIDef as uiDef

class NewNeteaseShopClientSystem(NeteaseBaseShopClientSystem):

    def __init__(self, namespace, systemName):
        NeteaseBaseShopClientSystem.__init__(self, namespace, systemName)
        eventID = conf.EngineNamespace + ':' + conf.EngineSystemName + ':' + conf.PythonServerEvent.lobbyGoodBuySucServerEvent
        server.RegisterEvent(eventID)
        self.mServerType = 0
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'UiInitFinished', self, self.OnUiInitFinished)
        self.UiDef = uiDef.newUIDef
        self.UiData = uiDef.newUIData
        self.mIsHideDesk = -1
        return

    def GetShopCache(self):
        return self.mShopCache

    def OnBackFromRn(self, routeName):
        print ('OnBackFromRn routeName={}').format(routeName)
        self.mShopCache.GetMoneyData(True)
        return

    def OnUiInitFinished(self, args):
        self.mUIMgr.Init(self, self.UiData, 'Minecraft', 'newNeteaseShop')
        if self.mIsHideDesk == -1:
            pass
        elif self.mIsHideDesk == 1:
            self.HideShopDesk()
        elif self.mIsHideDesk == 2:
            self.ShowShopDesk()
        self._closeCppShop()
        self._initConfig()
        return

    def _closeCppShop(self):
        if clientApi.GetPlatform() != 0:
            import gui
            gui.hide_netease_store(True)
            gui.update_hude_screen(False)
        return

    def _initConfig(self):
        if mc_game_ctrl.instance.is_in_lobby_game:
            self.mGameId = mc_game_ctrl.instance.getCurGameInfo()['res_id']
            self.mServerType = 1
        elif mc_game_ctrl.instance.is_in_network_game:
            self.mGameId = mc_game_ctrl.instance.getCurGameInfo()['id']
            self.mServerType = 2
        else:
            logger.info('NeteaseShop no support this game type')
        self.mGameId = str(self.mGameId)
        if self.mServerType == 0:
            logger.info('It is a local game, hide shop')
            self.HideShopDesk()
            return
        self.mCacheTime = 1
        comp = clientApi.GetEngineCompFactory().CreatePlayer(clientApi.GetLevelId())
        self.mUid = comp.getUid()
        if not self.mUid:
            logger.info('Get Uid error, hide shop')
            self.HideShopDesk()
            return
        self.mShopCache = ItemShopCache(self, self.mGameId, self.mCacheTime)
        self._initShopData()
        self._initDesk()
        return

    def _initShopData(self):
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopMain)
        ui.InitData()
        return

    def _initDesk(self):

        def querySuccess(data):
            if data['code'] != 0:
                print ('QuerySuccess but code error data={}').format(data)
                self.HideShopDesk()
                return
            if not data['entities']:
                self.HideShopDesk()
                return
            if self.mIsHideDesk != 1:
                self.ShowShopDesk()
            return

        def queryFail():
            self.HideShopDesk()
            return

        network_proxy.store_query_groups(self.mGameId, 0, 50, querySuccess, queryFail)
        return

    def StartForceShipItem(self):
        rpc.CServerRpc().UrgeShipEvent()
        self.mWaitingShipItem = True
        return

    def OnShipItemResult(self, data):
        if not self.mWaitingShipItem:
            return
        self.mWaitingShipItem = False
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopFlying)
        shipItemList = data['shipItemList']
        if not shipItemList:
            ui.ShowOne('未查询到商品到账')
            return
        for itemId in shipItemList:
            itemDetailCache = self.mShopCache.GetItemDetail(itemId)
            if not itemDetailCache:
                continue
            itemName = itemDetailCache.mData.get('name', '')
            if not itemName:
                continue
            ui.ShowTwo(itemName, '已到账成功')

        return

    def StartBuyItem(self, alreadyBuy, itemId, itemNum=1):

        def OnBuyRequestSuc(data):
            self.OnBuyRequestSuc(alreadyBuy, itemId, data)
            return

        def queryFunc():
            network_proxy.store_buy_item(itemId, itemNum, 2, OnBuyRequestSuc, self.OnBuyRequestFail)
            print ('store_buy_item start itemId={} itemNum={}').format(itemId, itemNum)
            return

        self.StartShopQuery(queryFunc)
        self.ShowBuyItemWaiting()
        return

    def OnQueryOrderSuc(self, alreadyBuy, itemId, orderId, buyType, repeat, data):
        if data['code'] != 0:
            print ('OnQueryOrderSuc but code error data={}').format(data)
            self.OnQueryOrderFail(alreadyBuy, itemId, orderId, buyType, repeat, data['message'])
            return
        if self.FinishShopQuery():
            return
        print ('OnQueryOrderSuc itemId={}').format(itemId)
        self.HideBuyItemWaiting()
        self.ShowBuySuccess()
        rpc.CServerRpc().StoreBuySuccServerEvent()
        if self.mServerType == 1:
            eventData = {'buyItem': itemId}
            rpc.CServerRpc().lobbyGoodBuySucServerEvent(eventData)
        self.mShopCache.GetItemDetail(itemId, True)
        self.mShopCache.GetMoneyData(True)
        return

    def Destroy(self):
        self.UnListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'UiInitFinished', self, self.OnUiInitFinished)
        self.mHasDestroy = True
        self.StopBuyTimer()
        return


def OnUiInitFinished_exceptV():
    return


return
