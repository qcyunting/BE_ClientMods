# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/neteaseShopCache.py
import time, mod.client.extraClientApi as clientApi
ClientSystem = clientApi.GetClientSystemCls()
import network_proxy

def get_mc_type():
    import mc_game_ctrl
    if mc_game_ctrl.instance.is_in_lobby_game:
        return 1
    else:
        return 0

    return


class ItemCacheBase(object):

    def __init__(self, system):
        super(ItemCacheBase, self).__init__()
        self.mClientSystem = system
        self.mOnQuerying = False
        self.mLastQuerySucTime = 0
        return


class MoneyCache(ItemCacheBase):

    def __init__(self, system):
        super(MoneyCache, self).__init__(system)
        self.mDiamond = 0
        self.mPoints = 0
        return

    def StartQuery(self):
        self.mOnQuerying = True

        def queryFunc():
            network_proxy.store_query_currency(self.QuerySuccess, self.QueryFail)
            print 'store_query_currency start'
            return

        self.mClientSystem.StartShopQuery(queryFunc)
        return

    def QuerySuccess(self, data):
        if data['code'] != 0:
            print ('QuerySuccess but code error data={}').format(data)
            self.QueryFail()
            return
        if self.mClientSystem.FinishShopQuery():
            return
        self.mOnQuerying = False
        self.mLastQuerySucTime = int(time.time())
        entity = data.get('entity', {})
        self.mDiamond = entity.get('pay_diamond', 0) + entity.get('free_diamond', 0)
        self.mPoints = entity.get('last_cash', 0) + entity.get('current_cash', 0)
        print ('MoneyCache QuerySuccess mDiamond={} mPoints={}').format(self.mDiamond, self.mPoints)
        self.mClientSystem.BroadcastEvent('QueryMoneyResult', {'suc': True, 'cache': self})
        return

    def QueryFail(self):
        if self.mClientSystem.FinishShopQuery():
            return
        self.mOnQuerying = False
        print 'MoneyCache QueryFail'
        self.mClientSystem.BroadcastEvent('QueryMoneyResult', {'suc': False})
        return


class ItemGroupCache(ItemCacheBase):

    def __init__(self, system):
        super(ItemGroupCache, self).__init__(system)
        self.mGroupList = []
        return

    def StartQuery(self, gameId):
        self.mOnQuerying = True
        self.mGroupList = []

        def queryFunc():
            network_proxy.store_query_groups(gameId, 0, 50, self.QuerySuccess, self.QueryFail)
            print 'store_query_groups start'
            return

        self.mClientSystem.StartShopQuery(queryFunc)
        return

    def QuerySuccess(self, data):
        if data['code'] != 0:
            print ('QuerySuccess but code error data={}').format(data)
            self.QueryFail()
            return
        if self.mClientSystem.FinishShopQuery():
            return
        self.mOnQuerying = False
        self.mLastQuerySucTime = int(time.time())
        for one in data['entities']:
            self.mGroupList.append((one['group_id'], one['name']))

        self.mClientSystem.GetShopCache().UpdateItemGroup(self)
        print ('ItemGroupCache QuerySuccess mGroupList={}').format(self.mGroupList)
        self.mClientSystem.BroadcastEvent('QueryItemGroupResult', {'suc': True, 'cache': self})
        return

    def QueryFail(self):
        if self.mClientSystem.FinishShopQuery():
            return
        print 'ItemGroupCache QueryFail'
        self.mOnQuerying = False
        self.mClientSystem.BroadcastEvent('QueryItemGroupResult', {'suc': False})
        return


class ItemSingleGroupCache(ItemCacheBase):

    def __init__(self, system, groupId, groupName):
        super(ItemSingleGroupCache, self).__init__(system)
        self.mGroupId = groupId
        self.mGroupName = groupName
        self.mLastQueryOffset = 0
        self.mLastQueryLimit = 0
        self.mItemList = []
        return

    def UpdateName(self, groupName):
        self.mGroupName = groupName
        return

    def StartQuery(self, gameId):
        self.mGameId = gameId
        self.mOnQuerying = True
        self.mItemList = []
        self.mLastQueryOffset = 0
        self.mLastQueryLimit = 50

        def queryFunc():
            network_proxy.store_search_by_group(self.mGameId, self.mGroupId, self.mLastQueryOffset, self.mLastQueryLimit, self.mGroupName, get_mc_type(), self.QuerySuccess, self.QueryFail)
            print ('store_search_by_group start mGroupId={} offset={} limit={}').format(self.mGroupId, self.mLastQueryOffset, self.mLastQueryLimit)
            return

        self.mClientSystem.StartShopQuery(queryFunc)
        return

    def QuerySuccess(self, data):
        if data['code'] != 0:
            print ('QuerySuccess but code error data={}').format(data)
            self.QueryFail()
            return
        if self.mClientSystem.FinishShopQuery():
            return
        for one in data['entities']:
            self.mItemList.append(one['item_id'])
            self.mClientSystem.GetShopCache().UpdateItemDetail(one)

        total = data['total']
        print ('ItemSingleGroupCache Step QuerySuccess total={}').format(total)
        if total > self.mLastQueryLimit:
            self.mLastQueryOffset += self.mLastQueryLimit

            def queryFunc():
                network_proxy.store_search_by_group(self.mGameId, self.mGroupId, self.mLastQueryOffset, self.mLastQueryLimit, self.mGroupName, 0, self.QuerySuccess, self.QueryFail)
                print ('store_search_by_group start mGroupId={} offset={} limit={}').format(self.mGroupId, self.mLastQueryOffset, self.mLastQueryLimit)
                return

            self.mClientSystem.StartShopQuery(queryFunc)
            return
        self.mOnQuerying = False
        self.mLastQuerySucTime = int(time.time())
        print ('ItemSingleGroupCache QuerySuccess groupId={} itemList={}').format(self.mGroupId, self.mItemList)
        self.mClientSystem.BroadcastEvent('QuerySingleItemGroupResult', {'suc': True, 'cache': self, 'groupId': (self.mGroupId)})
        return

    def QueryFail(self):
        if self.mClientSystem.FinishShopQuery():
            return
        print ('ItemSingleGroupCache QueryFail groupId={}').format(self.mGroupId)
        self.mOnQuerying = False
        self.mClientSystem.BroadcastEvent('QuerySingleItemGroupResult', {'suc': False, 'groupId': (self.mGroupId)})
        return


class ItemSingleDetailCache(ItemCacheBase):

    def __init__(self, system, itemId):
        super(ItemSingleDetailCache, self).__init__(system)
        self.mItemId = itemId
        self.mData = {}
        return

    def StartQuery(self, gameId):
        self.mOnQuerying = True

        def queryFunc():
            network_proxy.store_get_item_details(self.mItemId, self.QuerySuccess, self.QueryFail)
            print ('store_get_item_details start itemId={}').format(self.mItemId)
            return

        self.mClientSystem.StartShopQuery(queryFunc)
        return

    def UpdateFromGroup(self, one):
        self.mLastQuerySucTime = int(time.time())
        self.mData.update(one)
        return

    def QuerySuccess(self, data):
        if data['code'] != 0:
            print ('QuerySuccess but code error data={}').format(data)
            self.QueryFail()
            return
        if self.mClientSystem.FinishShopQuery():
            return
        self.mOnQuerying = False
        self.mLastQuerySucTime = int(time.time())
        self.mData.update(data['entity'])
        print ('ItemSingleDetailCache QuerySuccess itemId={}').format(self.mItemId)
        self.mClientSystem.BroadcastEvent('QueryItemDetailResult', {'suc': True, 'cache': self, 'itemId': (self.mItemId)})
        return

    def QueryFail(self):
        if self.mClientSystem.FinishShopQuery():
            return
        self.mOnQuerying = False
        print ('ItemSingleDetailCache QueryFail itemId={}').format(self.mItemId)
        self.mClientSystem.BroadcastEvent('QueryItemDetailResult', {'suc': False, 'itemId': (self.mItemId)})
        return


class ItemShopCache(object):

    def __init__(self, system, gameId, cacheTime):
        super(ItemShopCache, self).__init__()
        self.mClientSystem = system
        self.mGameId = gameId
        self.mCacheTime = cacheTime
        self.mGroupCache = ItemGroupCache(self.mClientSystem)
        self.mSingleGroupCache = {}
        self.mItemDetailCache = {}
        self.mMoneyCache = MoneyCache(self.mClientSystem)
        return

    def UpdateItemGroup(self, groupCache):
        oldGroupData = self.mSingleGroupCache
        self.mSingleGroupCache = {}
        for groupId, groupName in groupCache.mGroupList:
            if groupId in oldGroupData:
                obj = oldGroupData[groupId]
                obj.UpdateName(groupName)
                self.mSingleGroupCache[groupId] = obj
            else:
                self.mSingleGroupCache[groupId] = ItemSingleGroupCache(self.mClientSystem, groupId, groupName)

        return

    def GetGroupData(self):
        if self.mGroupCache.mOnQuerying:
            return
        else:
            now = int(time.time())
            lastQuerySucTime = self.mGroupCache.mLastQuerySucTime
            if now - lastQuerySucTime < self.mCacheTime:
                return self.mGroupCache
            self.mGroupCache.StartQuery(self.mGameId)
            return

    def GetSingleGroupData(self, groupId):
        singleGroupCache = self.mSingleGroupCache.get(groupId, None)
        if not singleGroupCache:
            return
        else:
            if singleGroupCache.mOnQuerying:
                return
            now = int(time.time())
            lastQuerySucTime = singleGroupCache.mLastQuerySucTime
            if now - lastQuerySucTime < self.mCacheTime:
                return singleGroupCache
            singleGroupCache.StartQuery(self.mGameId)
            return

    def GetItemDetail(self, itemId, force=False):
        itemDetailCache = self.mItemDetailCache.get(itemId, None)
        if not itemDetailCache:
            itemDetailCache = ItemSingleDetailCache(self.mClientSystem, itemId)
            self.mItemDetailCache[itemId] = itemDetailCache
        if itemDetailCache.mOnQuerying:
            return
        else:
            now = int(time.time())
            lastQuerySucTime = itemDetailCache.mLastQuerySucTime
            if not force and now - lastQuerySucTime < self.mCacheTime:
                return itemDetailCache
            itemDetailCache.StartQuery(self.mGameId)
            return

    def UpdateItemDetail(self, itemDict):
        itemId = itemDict['item_id']
        itemDetailCache = self.mItemDetailCache.get(itemId, None)
        if not itemDetailCache:
            itemDetailCache = ItemSingleDetailCache(self.mClientSystem, itemId)
            self.mItemDetailCache[itemId] = itemDetailCache
        itemDetailCache.UpdateFromGroup(itemDict)
        return

    def GetItemDictCache(self, itemId):
        itemDetailCache = self.mItemDetailCache.get(itemId, None)
        if not itemDetailCache:
            return
        else:
            return itemDetailCache.mData

    def GetMoneyData(self, force=False):
        if self.mMoneyCache.mOnQuerying:
            return
        else:
            now = int(time.time())
            lastQuerySucTime = self.mMoneyCache.mLastQuerySucTime
            if not force and now - lastQuerySucTime < self.mCacheTime:
                return self.mMoneyCache
            self.mMoneyCache.StartQuery()
            return


def QuerySuccess_newVersi0n():
    return
