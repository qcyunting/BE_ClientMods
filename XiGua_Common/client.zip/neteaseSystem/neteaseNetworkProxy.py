# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/neteaseNetworkProxy.py
import random, copy, mod.client.extraClientApi as clientApi
Item1 = {'info': '【商品介绍】\n  限购一次，购买后在游戏内获得1200花雨币，额外赠送1200花雨币！\n【使用指南】\n  - 可在游戏商城内购买所有的付费道具\n  - 购买后，游戏内自动到帐\n【问题反馈QQ】: 1787397608', 
   'image_md5': '2aadaac6cd8ae8a179a5a46b5d6a1902', 
   'name': '1200花雨币(双倍)', 
   'diamond': 1200, 
   'short_intro': '', 
   'tExpire': 0, 
   'is_buy': 0, 
   'discount': 100, 
   'extras': {'user_first_charge': 0, 
              'is_first_charge': 0, 
              'first_charge_img_md5': '', 
              'first_charge_img': ''}, 
   'image_url': 'https://x19.fp.ps.netease.com/file/5c4fc1497f9d2ad46f82c6976xzkZBmY02', 
   'roll_pics': [], 'buy_expire_day': (-1), 
   'item_id': '4628904246114061708', 
   'res_version': 0, 
   'mc_type': 0, 
   'res_size': 0, 
   'points': 0, 
   'buy_limit': 20, 
   'buy_count': 3}
Item2 = {'info': '【商品介绍】\n  限购一次，购买后在游戏内获得1200花雨币，额外赠送1200花雨币！\n【使用指南】\n  - 可在游戏商城内购买所有的付费道具\n  - 购买后，游戏内自动到帐\n【问题反馈QQ】: 1787397608', 
   'image_md5': '2aadaac6cd8ae8a179a5a46b5d6a1902', 
   'name': '120花雨币(双倍)', 
   'diamond': 0, 
   'short_intro': '', 
   'tExpire': 0, 
   'is_buy': 0, 
   'discount': 100, 
   'extras': {'user_first_charge': 0, 
              'is_first_charge': 0, 
              'first_charge_img_md5': '', 
              'first_charge_img': ''}, 
   'image_url': 'https://x19.fp.ps.netease.com/file/5c4fc1497f9d2ad46f82c6976xzkZBmY02', 
   'roll_pics': [], 'buy_expire_day': (-1), 
   'item_id': '4628904246114061708', 
   'res_version': 0, 
   'mc_type': 0, 
   'res_size': 0, 
   'points': 1200, 
   'buy_limit': 20, 
   'buy_count': 3}
Item3 = {'info': '【商品介绍】\n  限购一次，购买后在游戏内获得1200花雨币，额外赠送1200花雨币！\n【使用指南】\n  - 可在游戏商城内购买所有的付费道具\n  - 购买后，游戏内自动到帐\n【问题反馈QQ】: 1787397608', 
   'image_md5': '2aadaac6cd8ae8a179a5a46b5d6a1902', 
   'name': '200花雨币(双倍)', 
   'diamond': 200, 
   'short_intro': '', 
   'tExpire': 0, 
   'is_buy': 0, 
   'discount': 80, 
   'extras': {'user_first_charge': 0, 
              'is_first_charge': 0, 
              'first_charge_img_md5': '', 
              'first_charge_img': ''}, 
   'image_url': 'https://x19.fp.ps.netease.com/file/5c4fc1497f9d2ad46f82c6976xzkZBmY02', 
   'roll_pics': [], 'buy_expire_day': (-1), 
   'item_id': '4628904246114061708', 
   'res_version': 0, 
   'mc_type': 0, 
   'res_size': 0, 
   'points': 0, 
   'buy_limit': 20, 
   'buy_count': 20}
Item4 = {'info': '【商品介绍】\n  限购一次，购买后在游戏内获得1200花雨币，额外赠送1200花雨币！\n【使用指南】\n  - 可在游戏商城内购买所有的付费道具\n  - 购买后，游戏内自动到帐\n【问题反馈QQ】: 1787397608', 
   'image_md5': '2aadaac6cd8ae8a179a5a46b5d6a1902', 
   'name': '20花雨币(双倍)', 
   'diamond': 200, 
   'short_intro': '', 
   'tExpire': 0, 
   'is_buy': 0, 
   'discount': 100, 
   'extras': {'user_first_charge': 0, 
              'is_first_charge': 0, 
              'first_charge_img_md5': '', 
              'first_charge_img': ''}, 
   'image_url': 'https://x19.fp.ps.netease.com/file/5c4fc1497f9d2ad46f82c6976xzkZBmY02', 
   'roll_pics': [], 'buy_expire_day': (-1), 
   'item_id': '4628904246114061708', 
   'res_version': 0, 
   'mc_type': 0, 
   'res_size': 0, 
   'points': 0, 
   'buy_limit': 0, 
   'buy_count': 0}
Item5 = {'info': '【商品介绍】\n  限购一次，购买后在游戏内获得1200花雨币，额外赠送1200花雨币！\n【使用指南】\n  - 可在游戏商城内购买所有的付费道具\n  - 购买后，游戏内自动到帐\n【问题反馈QQ】: 1787397608', 
   'image_md5': '2aadaac6cd8ae8a179a5a46b5d6a1902', 
   'name': '333花雨币(双倍)', 
   'diamond': 200, 
   'short_intro': '', 
   'tExpire': 0, 
   'is_buy': 0, 
   'discount': 60, 
   'extras': {'user_first_charge': 0, 
              'is_first_charge': 0, 
              'first_charge_img_md5': '', 
              'first_charge_img': ''}, 
   'image_url': 'https://x19.fp.ps.netease.com/file/5c4fc1497f9d2ad46f82c6976xzkZBmY02', 
   'roll_pics': [], 'buy_expire_day': (-1), 
   'item_id': '4628904246114061708', 
   'res_version': 0, 
   'mc_type': 0, 
   'res_size': 0, 
   'points': 0, 
   'buy_limit': 0, 
   'buy_count': 0}
ProtoItem = {0: Item1, 
   1: Item2, 
   2: Item3, 
   3: Item4, 
   4: Item5}
GroupData = {'4627718771650549913': [
                         43, 44, 
                         34, 45, 46, 47, 48, 49, 
                         50, 51, 52, 53, 54, 55, 
                         56, 57, 58, 59, 60, 32], 
   '4628779729187500516': [
                         62, 63, 
                         64, 65, 66, 67, 68, 69, 
                         70, 71, 72, 73, 74, 75, 
                         76], 
   '4642045557479422358': [
                         78, 79, 
                         80, 81, 82, 83, 84]}
ItemData = {}
for itemList in GroupData.itervalues():
    for idx, itemId in enumerate(itemList):
        offset = idx % 5
        itemDict = copy.deepcopy(ProtoItem[offset])
        itemDict['item_id'] = str(itemId)
        ItemData[str(itemId)] = itemDict

def store_query_currency(sucCb, failCb):

    def delaySuc():
        data = {'code': 0, 'message': '', 
           'total': 3, 
           'details': '', 
           'entity': {'pay_diamond': 915436, 
                      'free_diamond': 119800, 
                      'last_cash': 0, 
                      'current_cash': 200, 
                      'currency_time': 1628167853, 
                      'last_cash_time': 202107, 
                      'current_cash_time': 202108}}
        sucCb(data)
        return

    def delayFail():
        failCb()
        return

    comp = clientApi.GetEngineCompFactory().CreateGame(clientApi.GetLevelId())
    comp.AddTimer(3.0, delaySuc)
    return


def store_query_groups(gameId, begin, offset, sucCb, failCb):

    def delaySuc():
        data = {'code': 0, 
           'message': '', 
           'total': 3, 
           'details': '', 
           'entities': [{'group_id': '4627718771650549913', 'name': '商品'}, {'group_id': '4628779729187500516', 'name': '限时特惠'}, {'group_id': '4642045557479422358', 'name': 'Test'}]}
        sucCb(data)
        return

    def delayFail():
        failCb()
        return

    comp = clientApi.GetEngineCompFactory().CreateGame(clientApi.GetLevelId())
    comp.AddTimer(3.0, delaySuc)
    return


def store_search_by_group(gameId, groupId, begin, offset, groupName, mcType, sucCb, failCb):
    itemIdList = GroupData.get(groupId, [])
    entities = []
    for itemId in itemIdList:
        itemDict = copy.deepcopy(ItemData[str(itemId)])
        entities.append(itemDict)

    def delaySuc():
        data = {'code': 0, 'message': '', 
           'total': (len(entities)), 
           'details': '', 
           'entities': entities}
        sucCb(data)
        return

    def delayFail():
        failCb()
        return

    comp = clientApi.GetEngineCompFactory().CreateGame(clientApi.GetLevelId())
    comp.AddTimer(1.0, delaySuc)
    return


def store_get_item_details(itemId, sucCb, failCb):

    def delaySuc():
        data = {'code': 0, 
           'message': '', 
           'details': '', 
           'entity': (copy.deepcopy(ItemData[str(itemId)]))}
        sucCb(data)
        return

    def delayFail():
        failCb()
        return

    comp = clientApi.GetEngineCompFactory().CreateGame(clientApi.GetLevelId())
    comp.AddTimer(3.0, delaySuc)
    return


def store_buy_item(itemId, itemNum, mcType, sucCb, failCb):

    def delaySuc():
        data = {'code': 0, 
           'message': '', 
           'details': '', 
           'entity': {'entity_id': '4649240156816157571', 
                      'buy_type': '4'}}
        sucCb(data)
        return

    def delayFail():
        failCb()
        return

    comp = clientApi.GetEngineCompFactory().CreateGame(clientApi.GetLevelId())
    comp.AddTimer(2.0, delaySuc)
    return


def store_buy_item_result(orderId, buyType, sucCb, failCb):

    def delaySuc():
        data = {'code': 0, 
           'message': '', 
           'details': '', 
           'entity': {'game_id': '4624928396213613153'}}
        sucCb(data)
        return

    def delayFail():
        failCb()
        return

    comp = clientApi.GetEngineCompFactory().CreateGame(clientApi.GetLevelId())
    factor = random.randint(1, 100)
    if factor > 80:
        comp.AddTimer(2.0, delaySuc)
    else:
        comp.AddTimer(2.0, delayFail)
    return


def delayFail_exceptV():
    return
