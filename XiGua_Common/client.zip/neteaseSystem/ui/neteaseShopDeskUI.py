# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/ui/neteaseShopDeskUI.py
import mod.client.extraClientApi as clientApi
ViewBinder = clientApi.GetViewBinderCls()
ViewRequest = clientApi.GetViewViewRequestCls()
from client.neteaseSystem.ui.neteaseShopUIScreenNode import ExtraScreenNode

class ShopDeskUIScreen(ExtraScreenNode):

    def __init__(self, namespace, name, param):
        ExtraScreenNode.__init__(self, namespace, name, param)
        self.SetNeedChangeHud(False)
        self.mOkCb = None
        return

    def InitScreen(self):
        self.ChangeScreenVisible(False)
        return

    def Destroy(self):
        return

    def Update(self):
        return

    def Create(self):
        self.AddButtonUpTouchEventHandler('/main_pnl/btn_shop', self.OnButtonOpenShop)
        return

    def OnButtonOpenShop(self, args):
        self.mClientSystem.OnOpenShop({})
        return

    def HideShopDesk(self):
        self.ChangeScreenVisible(False)
        return

    def ShowShopDesk(self):
        self.ChangeScreenVisible(True)
        return
