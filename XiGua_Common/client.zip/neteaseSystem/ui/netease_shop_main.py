# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/ui/netease_shop_main.py
import mod.client.extraClientApi as clientApi
ViewBinder = clientApi.GetViewBinderCls()
ViewRequest = clientApi.GetViewViewRequestCls()
from mod.common.system.systemRegister import client
import mod.common.system.eventConf as conf
from client.neteaseSystem.ui.neteaseShopUIScreenNode import ExtraScreenNode

class ShopMainUIScreen(ExtraScreenNode):

    def __init__(self, namespace, name, param):
        ExtraScreenNode.__init__(self, namespace, name, param)
        self.mShowSearchData = False
        self.mLastInput = ''
        self.mRecentItemList = []
        self.mSelectGroupName = None
        self.mSelectGroupId = None
        self.mSelectItemName = None
        self.mGroupList = []
        self.mGroupToItemList = {}
        self.mItemIdToData = {}
        self.mItemNameToId = {}
        self.mIsGoodsMoving = False
        self.mShouldPlayClickSound = True
        return

    def InitScreen(self):
        self.ChangeScreenVisible(False)
        return

    def InitData(self):
        self.mClientSystem.GetShopCache().GetMoneyData()
        self.mClientSystem.GetShopCache().GetGroupData()
        self.mClientSystem.GetShopCache().GetSingleGroupData(self.mSelectGroupId)
        return

    def Destroy(self):
        self.ReleaseUrgeTimer()
        return

    def Update(self):
        return

    def ChangeScreenVisible(self, flag):
        ExtraScreenNode.ChangeScreenVisible(self, flag)
        self.OnScreenSizeChange()
        return

    def Create(self):
        self.UpdateScreen(True)
        mainBase = ''
        scrollBase = mainBase + '/main_pnl/img_bg/scroll_tab'
        scrollViewUIControl = self.GetBaseUIControl(scrollBase).asScrollView()
        scrollBase = scrollViewUIControl.GetScrollViewContentPath()
        buttonBase = scrollBase + '/btn_tab_base'
        self.mGroupPageData = {'parent': scrollBase, 
           'parentSize': (self.GetSize(scrollBase)), 
           'buttonBase': buttonBase, 
           'buttonSize': (self.GetSize(buttonBase)), 
           'buttonPos': (self.GetPosition(buttonBase)), 
           'offset': 2}
        self.SetVisible(buttonBase, False)
        self.mGroupPageList = []
        self.mGroupPageSize = 0
        self.ResizeGroupPage(0)
        scrollBase = mainBase + '/main_pnl/img_bg/scroll_goods'
        scrollViewUIControl = self.GetBaseUIControl(scrollBase).asScrollView()
        scrollBase = scrollViewUIControl.GetScrollViewContentPath()
        goodsBase = scrollBase + '/pnl_goods_base'
        goodsEmpty = scrollBase + '/pnl_goods_empty'
        buttonPos = self.GetPosition(goodsBase)
        self.mGoodsPnlData = {'parent': scrollBase, 
           'parentSize': (self.GetSize(scrollBase)), 
           'buttonBase': goodsBase, 
           'goodsEmpty': goodsEmpty, 
           'buttonSize': (self.GetSize(goodsBase)), 
           'buttonPos': (
                       -2, buttonPos[1]), 
           'offsetX': 1, 
           'offsetY': 2}
        grid = (self.mGoodsPnlData['parentSize'][0] + self.mGoodsPnlData['offsetX'] - 2 * self.mGoodsPnlData['buttonPos'][0]) // (self.mGoodsPnlData['buttonSize'][0] + self.mGoodsPnlData['offsetX'])
        self.mGoodsPnlData['grid'] = grid
        self.SetVisible(goodsBase, False)
        self.SetVisible(goodsEmpty, False)
        self.mGoodsPnlList = []
        self.mGoodsPnlSize = 0
        self.ResizeGoodsPnl(0)
        self.AddButtonUpTouchEventHandler(mainBase + '/main_pnl/img_bg/pnl_top/btn_close', self.OnButtonCancel)
        self.AddButtonUpTouchEventHandler(mainBase + '/main_pnl/img_bg/pnl_top/btn_diamond_add', self.OnButtonCharge)
        self.mUrgeCountdown = 0
        self.mUrgeTimer = None
        self.mButtonUrge = mainBase + '/main_pnl/img_bg/pnl_tool/btn_urge'
        self.SetVisible(self.mButtonUrge, True)
        self.AddButtonUpTouchEventHandler(self.mButtonUrge, self.OnButtonUrge)
        self.mButtonUrgeDisable = mainBase + '/main_pnl/img_bg/pnl_tool/btn_urge_disable'
        self.SetTouchEnable(self.mButtonUrgeDisable, False)
        self.SetVisible(self.mButtonUrgeDisable, False)
        self.AddButtonUpTouchEventHandler(mainBase + '/main_pnl/img_bg/pnl_tool/pnl_search/btn_clear', self.OnButtonClear)
        self.mPanelTool = mainBase + '/main_pnl/img_bg/pnl_tool'
        self.mPanelTop = mainBase + '/main_pnl/img_bg/pnl_top'
        self.mTextEditPath = mainBase + '/main_pnl/img_bg/pnl_tool/pnl_search/text_edit_search'
        return

    def InitSystem(self, system, nameSpace, systemName):
        ExtraScreenNode.InitSystem(self, system, nameSpace, systemName)
        self.mClientSystem.ListenForEvent(nameSpace, systemName, 'QueryItemDetailResult', self, self.OnQueryItemDetailResult)
        self.mClientSystem.ListenForEvent(nameSpace, systemName, 'QueryMoneyResult', self, self.OnQueryMoneyResult)
        self.mClientSystem.ListenForEvent(nameSpace, systemName, 'QueryItemGroupResult', self, self.OnQueryItemGroupResult)
        self.mClientSystem.ListenForEvent(nameSpace, systemName, 'QuerySingleItemGroupResult', self, self.OnQuerySingleItemGroupResult)
        return

    def ResizeGroupPage(self, size):
        if size == self.mGroupPageSize:
            return
        self.mGroupPageSize = size
        lackNum = size - len(self.mGroupPageList)
        if lackNum > 0:
            beginIndex = len(self.mGroupPageList)
            for idx in xrange(lackNum):
                self.CloneGroupPageButton(beginIndex + idx)

        for idx, btn in enumerate(self.mGroupPageList):
            if idx < size:
                self.SetVisible(btn, True)
            else:
                self.SetVisible(btn, False)

        scrollData = self.mGroupPageData
        height = scrollData['buttonPos'][1] + size * (scrollData['buttonSize'][1] + scrollData['offset'])
        height = max(height, scrollData['parentSize'][1])
        width = scrollData['parentSize'][0]
        self.SetSize(scrollData['parent'], (width, height))
        return

    def CloneGroupPageButton(self, idx):
        scrollData = self.mGroupPageData
        name = 'group_page_%d' % idx
        self.Clone(scrollData['buttonBase'], scrollData['parent'], name)
        name = '%s/%s' % (scrollData['parent'], name)
        self.mGroupPageList.append(name)
        height = scrollData['buttonPos'][1] + idx * (scrollData['buttonSize'][1] + scrollData['offset'])
        self.SetPosition(name, (scrollData['buttonPos'][0], height))
        buttonUIControl = self.GetBaseUIControl(name).asButton()
        buttonUIControl.AddTouchEventParams({'isSwallow': True})
        buttonUIControl.SetButtonTouchUpCallback(self.OnGroupPageChange)
        return

    def ResizeGoodsPnl(self, size):
        if size == self.mGoodsPnlSize:
            return
        self.mGoodsPnlSize = size
        lackNum = size - len(self.mGoodsPnlList)
        if lackNum > 0:
            beginIndex = len(self.mGoodsPnlList)
            for idx in xrange(lackNum):
                self.CloneGoodsPanel(beginIndex + idx)

        for idx, btn in enumerate(self.mGoodsPnlList):
            if idx < size:
                self.SetVisible(btn, True)
            else:
                self.SetVisible(btn, False)

        scrollData = self.mGoodsPnlData
        sizeY = (size + scrollData['grid'] - 1) // scrollData['grid']
        height = scrollData['buttonPos'][1] + sizeY * (scrollData['buttonSize'][1] + scrollData['offsetY'])
        height = max(height, scrollData['parentSize'][1])
        width = scrollData['parentSize'][0]
        self.SetSize(scrollData['parent'], (width, height))
        return

    def CloneGoodsPanel(self, idx):
        scrollData = self.mGoodsPnlData
        name = 'group_page_%d' % idx
        self.Clone(scrollData['buttonBase'], scrollData['parent'], name)
        name = '%s/%s' % (scrollData['parent'], name)
        self.mGoodsPnlList.append(name)
        gridX = idx % scrollData['grid']
        gridY = idx // scrollData['grid']
        width = scrollData['buttonPos'][0] + gridX * (scrollData['buttonSize'][0] + scrollData['offsetX'])
        height = scrollData['buttonPos'][1] + gridY * (scrollData['buttonSize'][1] + scrollData['offsetY'])
        self.SetPosition(name, (width, height))
        buttonUIControl = self.GetBaseUIControl('%s/btn_goods_buy' % name).asButton()
        buttonUIControl.AddTouchEventParams({'isSwallow': True})
        buttonUIControl.SetButtonTouchUpCallback(self.OnClickGoodsBuy)
        buttonUIControl.SetButtonTouchDownCallback(self.OnTouchDownGoods)
        buttonUIControl.SetButtonTouchMoveCallback(self.OnMoveGoods)
        buttonUIControl.SetButtonTouchMoveInCallback(self.OnMoveInGoods)
        buttonUIControl = self.GetBaseUIControl('%s/pnl_goods_pic/btn_goods_pic' % name).asButton()
        buttonUIControl.AddTouchEventParams({'isSwallow': True})
        buttonUIControl.SetButtonTouchUpCallback(self.OnClickGoodsPicBuy)
        buttonUIControl.SetButtonTouchDownCallback(self.OnTouchDownGoods)
        buttonUIControl.SetButtonTouchMoveCallback(self.OnMoveGoods)
        buttonUIControl.SetButtonTouchMoveInCallback(self.OnMoveInGoods)
        return

    def OnQueryItemDetailResult(self, data):
        if not data['suc']:
            return
        if not self.mIsShow:
            return
        itemId = data['itemId']
        if itemId not in self.mRecentItemList:
            return
        index = self.mRecentItemList.index(itemId)
        itemDict = data['cache'].mData
        self.DrawItemDetail(self.mGoodsPnlList[index], itemDict)
        return

    def OnQueryMoneyResult(self, data):
        if not data['suc']:
            return
        if not self.mIsShow:
            return
        moneyData = data['cache']
        self.mDiamond = moneyData.mDiamond
        self.mPoints = moneyData.mPoints
        self.DrawTopPanel()
        return

    def OnScreenSizeChange(self):
        comp = clientApi.GetEngineCompFactory().CreateGame(clientApi.GetLevelId())
        comp.AddTimer(0.05, self._screenSizeChange)
        return

    def _screenSizeChange(self):
        ListNum = len(self.mGoodsPnlList)
        mainBase = ''
        scrollBase = mainBase + '/main_pnl/img_bg/scroll_goods'
        scroll_goods_size = self.GetSize(scrollBase)
        self.mGoodsPnlData['parentSize'] = scroll_goods_size
        self.mGoodsPnlData['buttonSize'] = (scroll_goods_size[0] * 0.24, scroll_goods_size[0] * 0.24 * 1.44)
        grid = (self.mGoodsPnlData['parentSize'][0] + self.mGoodsPnlData['offsetX'] - 2 * self.mGoodsPnlData['buttonPos'][0]) // (self.mGoodsPnlData['buttonSize'][0] + self.mGoodsPnlData['offsetX'])
        self.mGoodsPnlData['grid'] = grid
        scrollData = self.mGoodsPnlData
        for idx in xrange(ListNum):
            name = 'group_page_%d' % idx
            name = '%s/%s' % (scrollData['parent'], name)
            gridX = idx % scrollData['grid']
            gridY = idx // scrollData['grid']
            width = scrollData['buttonPos'][0] + gridX * (scrollData['buttonSize'][0] + scrollData['offsetX'])
            height = scrollData['buttonPos'][1] + gridY * (scrollData['buttonSize'][1] + scrollData['offsetY'])
            self.SetPosition(name, (width, height))

        return

    def OnQueryItemGroupResult(self, data):
        if not data['suc']:
            return
        else:
            self.UpdateGroupData(data['cache'])
            existGroupIds = []
            groupList = data['cache'].mGroupList
            for groupId, groupName in groupList:
                existGroupIds.append(groupId)
                singleGroupCache = self.mClientSystem.GetShopCache().GetSingleGroupData(groupId)
                if groupName == self.mSelectGroupName:
                    self.mSelectGroupId = groupId
                if not singleGroupCache:
                    continue
                self.UpdateSingleGroupData(groupId, singleGroupCache)

            if self.mSelectGroupId not in existGroupIds:
                self.mSelectGroupId = None
            if self.mSelectGroupId is None and self.mGroupList:
                self.mSelectGroupId = self.mGroupList[0]['groupId']
            if not self.mIsShow:
                return
            self.SetVisible(self.mPanelTool, True)
            self.DrawLeftPanel()
            if self.mShowSearchData:
                return
            self.mRecentItemList = []
            if self.mSelectGroupId is not None:
                self.mRecentItemList = self.mGroupToItemList.get(self.mSelectGroupId, [])
            self.DrawRightPanel()
            if self.mSelectItemName:
                self.OpenSingleItemByName(self.mSelectGroupName, self.mSelectItemName)
                self.mSelectItemName = None
            return

    def OnQuerySingleItemGroupResult(self, data):
        if not data['suc']:
            return
        else:
            groupId = data['groupId']
            singleGroupCache = data['cache']
            self.UpdateSingleGroupData(groupId, singleGroupCache)
            if not self.mIsShow:
                return
            if self.mShowSearchData:
                return
            if self.mSelectGroupId is None or self.mSelectGroupId != groupId:
                return
            self.mRecentItemList = []
            if self.mSelectGroupId is not None:
                self.mRecentItemList = self.mGroupToItemList.get(self.mSelectGroupId, [])
            self.DrawRightPanel()
            return

    def UpdateGroupData(self, groupData):
        self.mGroupList = []
        if not groupData:
            return
        for groupId, groupName in groupData.mGroupList:
            data = {'groupId': groupId, 
               'groupName': groupName}
            self.mGroupList.append(data)

        return

    def UpdateSingleGroupData(self, groupId, singleGroupData):
        if not singleGroupData:
            return
        else:
            self.mGroupToItemList[groupId] = []
            for itemId in singleGroupData.mItemList:
                itemDict = self.mClientSystem.GetShopCache().GetItemDictCache(itemId)
                if itemDict is None:
                    continue
                self.mGroupToItemList[groupId].append(itemId)
                itemDict['groupId'] = groupId
                self.mItemIdToData[itemId] = itemDict
                name = itemDict['name']
                if name not in self.mItemNameToId:
                    self.mItemNameToId[name] = set()
                self.mItemNameToId[name].add(itemId)

            return

    def GetBuyLimitInfo(self, itemDict):
        if not itemDict:
            return (0, None)
        else:
            limit = itemDict.get('buy_limit', 0)
            if limit <= 0:
                return (0, None)
            if limit >= self.MaxBuyLimitNumber:
                return (0, None)
            hasBuy = itemDict.get('buy_count', 0)
            return (hasBuy, limit)

    def FindItemsByName(self, input):
        itemIdList = []
        if not input:
            return itemIdList
        for name, itemIds in self.mItemNameToId.iteritems():
            if input in name:
                for _id in itemIds:
                    itemIdList.append(_id)

        return itemIdList

    def GetGroupIdByName(self, GroupName):
        if not GroupName:
            return
        else:
            for index in range(len(self.mGroupList)):
                if GroupName == str(self.mGroupList[index].get('groupName', '')):
                    return self.mGroupList[index]['groupId']

            return

    def Show(self, data):
        self.mClientSystem.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'PlaySoundClientEvent', self, self.OnPlaySoundClientEvent)
        self.mSelectItemName = None
        self.mSelectGroupId = None
        self.mSelectGroupName = None
        self.mSelectGroupName = data.get('groupName')
        self.mSelectItemName = data.get('itemName')
        self.ChangeScreenVisible(True)
        moneyData = self.mClientSystem.GetShopCache().GetMoneyData()
        if moneyData:
            self.mDiamond = moneyData.mDiamond
            self.mPoints = moneyData.mPoints
        else:
            self.mDiamond = 0
            self.mPoints = 0
        self.DrawTopPanel()
        groupData = self.mClientSystem.GetShopCache().GetGroupData()
        if not groupData:
            self.DrawEmptyGroup()
            return
        else:
            self.SetVisible(self.mPanelTool, True)
            self.mShowSearchData = False
            self.UpdateGroupData(groupData)
            if self.mGroupList:
                for index in range(len(self.mGroupList)):
                    if self.mSelectGroupName and str(self.mGroupList[index].get('groupName', '')) == self.mSelectGroupName:
                        self.mSelectGroupId = self.mGroupList[index]['groupId']

            if self.mSelectGroupId is None and self.mGroupList:
                self.mSelectGroupId = self.mGroupList[0]['groupId']
            self.DrawLeftPanel()
            singleGroupData = self.mClientSystem.GetShopCache().GetSingleGroupData(self.mSelectGroupId)
            self.UpdateSingleGroupData(self.mSelectGroupId, singleGroupData)
            self.mRecentItemList = []
            if self.mSelectGroupId is not None:
                self.mRecentItemList = self.mGroupToItemList.get(self.mSelectGroupId, [])
            self.DrawRightPanel()
            if self.mSelectItemName:
                self.OpenSingleItemByName(self.mSelectGroupName, self.mSelectItemName)
                self.mSelectItemName = None
            return

    def CloseShop(self):
        self.mClientSystem.UnListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'PlaySoundClientEvent', self, self.OnPlaySoundClientEvent)
        self.ChangeScreenVisible(False)
        eventID = conf.EngineNamespace + ':' + conf.EngineSystemName + ':' + conf.PythonClientEvent.CloseNeteaseShopEvent
        client.PostEvent(eventID, {})
        return

    def DrawTopPanel(self):
        self.SetText(self.mPanelTop + '/img_diamond_base/lb_diamond_have', str(self.mDiamond))
        self.SetText(self.mPanelTop + '/img_point_base/lb_point_have', str(self.mPoints))
        return

    def DrawEmptyGroup(self):
        self.ResizeGroupPage(0)
        self.SetVisible(self.mPanelTool, False)
        self.DrawGoodsHint('查询商品信息中，请稍候...')
        self.ResizeGoodsPnl(0)
        return

    def DrawLeftPanel(self):
        length = len(self.mGroupList)
        self.ResizeGroupPage(length)
        for idx, data in enumerate(self.mGroupList):
            button = self.mGroupPageList[idx]
            self.SetButtonText(button, data['groupName'])
            if not self.mShowSearchData and data['groupId'] == self.mSelectGroupId:
                self.SetSprite(button + '/default', 'textures/ui/netease_shop/btn01_click.png')
            else:
                self.SetSprite(button + '/default', 'textures/ui/netease_shop/btn01.png')

        return

    def DrawRightPanel(self):
        length = len(self.mRecentItemList)
        self.ResizeGoodsPnl(length)
        for idx, itemId in enumerate(self.mRecentItemList):
            part = self.mGoodsPnlList[idx]
            self.DrawItemDetail(part, self.mItemIdToData[itemId])

        if self.mRecentItemList:
            self.DrawGoodsHint(None)
        elif self.mShowSearchData:
            self.DrawGoodsHint('未找到相关物品')
        elif self.mSelectGroupId is None:
            self.DrawGoodsHint('请点击左边商品分类按钮...')
        elif self.mGroupToItemList.has_key(self.mSelectGroupId):
            self.DrawGoodsHint('此分类暂无商品')
        else:
            self.DrawGoodsHint('查询商品信息中，请稍候...')
        return

    def DrawGoodsHint(self, text=None):
        basePath = self.mGoodsPnlData['goodsEmpty']
        if text:
            self.SetVisible(basePath, True)
            self.SetText(basePath + '/lb_nogoods', text)
        else:
            self.SetVisible(basePath, False)
        return

    def DrawItemDetail(self, part, itemDict):
        text = itemDict.get('name', '')
        self.SetText(part + '/lb_goods_name', text)
        extras = itemDict.get('extras', {})
        is_first_charge = int(extras.get('is_first_charge', 0))
        user_first_charge = int(extras.get('user_first_charge', 0))
        if is_first_charge and not user_first_charge:
            url = extras.get('first_charge_img', '')
        else:
            url = itemDict.get('image_url', '')
        imageUIControl = self.GetBaseUIControl(part + '/pnl_goods_pic/img_goods_pic_bg/pnl_goods_pic_normal/img_goods_pic_normal').asImage()
        import clienthttp
        clienthttp.HttpPool().RequestFile(url, imageUIControl._callbackSpriteStore)
        hasBuy, limit = self.GetBuyLimitInfo(itemDict)
        basePath = part + '/pnl_goods_pic/img_goods_pic_bg/pnl_goods_pic_limit'
        if not limit:
            self.SetVisible(basePath, False)
        else:
            self.SetVisible(basePath, True)
            canbuy = max(0, limit - hasBuy)
            self.SetText(basePath + '/img_good_pic_limit_bg/lb_good_pic_limit_num', '%d/%d' % (canbuy, limit))
        basePath = part + '/btn_goods_buy'
        imgPath = basePath + '/img_goods_prize_icon'
        diamond = itemDict.get('diamond', 0)
        if diamond > 0:
            self.SetSprite(imgPath, 'textures/ui/netease_shop/icon_prize01.png')
            realPrice = diamond
        else:
            self.SetSprite(imgPath, 'textures/ui/netease_shop/icon_prize02.png')
            realPrice = itemDict.get('points', 0)
        discount = itemDict.get('discount', 100)
        if discount >= 100 or discount == 0:
            self.SetVisible(basePath + '/pnl_goods_price_normal', True)
            self.SetVisible(basePath + '/pnl_goods_prize_discount', False)
            self.SetText(basePath + '/pnl_goods_price_normal/lb_goods_prize_normal', str(realPrice))
        else:
            self.SetVisible(basePath + '/pnl_goods_price_normal', False)
            self.SetVisible(basePath + '/pnl_goods_prize_discount', True)
            discountPath = basePath + '/pnl_goods_prize_discount'
            fakePrice = int(realPrice * 100.0 / discount)
            self.SetText(discountPath + '/lb_goods_price_org', str(fakePrice))
            self.SetText(discountPath + '/lb_goods_prize_discount', str(realPrice))
            self.SetText(discountPath + '/img_goods_discount_base/lb_goods_discount_num', ('-{}').format(100 - discount))
            self.SetText(discountPath + '/img_goods_discount_base/lb_goods_discount_percent', '%%')
        goods_state = itemDict.get('goods_state')
        if goods_state == 0:
            self.SetVisible(basePath + '/pnl_goods_price_normal', True)
            self.SetVisible(basePath + '/pnl_goods_prize_discount', False)
            self.SetVisible(imgPath, False)
            self.SetText(basePath + '/pnl_goods_price_normal/lb_goods_prize_normal', '非卖品')
            self.SetSprite(basePath + '/default', 'textures/ui/netease_shop/btn01_select')
            self.SetSprite(basePath + '/hover', 'textures/ui/netease_shop/btn01_select')
            self.SetSprite(basePath + '/pressed', 'textures/ui/netease_shop/btn01_select')
            self.SetTouchEnable(basePath, False)
        else:
            self.SetVisible(imgPath, True)
            self.SetSprite(basePath + '/default', 'textures/ui/netease_shop/btn01')
            self.SetSprite(basePath + '/hover', 'textures/ui/netease_shop/btn01_hover')
            self.SetSprite(basePath + '/pressed', 'textures/ui/netease_shop/btn01_click')
            self.SetTouchEnable(basePath, True)
        return

    def DoChangeSelectGroupPage(self, idx):
        print 'DoChangeSelectGroupPage', idx
        if idx >= len(self.mGroupList):
            return
        groupId = self.mGroupList[idx]['groupId']
        if not self.mShowSearchData and self.mSelectGroupId == groupId:
            return
        self.mShowSearchData = False
        self.mLastInput = ''
        textEditBoxUIControl = self.GetBaseUIControl(self.mTextEditPath).asTextEditBox()
        textEditBoxUIControl.SetEditText('')
        self.mSelectGroupId = groupId
        self.DrawLeftPanel()
        self.mRecentItemList = self.mGroupToItemList.get(self.mSelectGroupId, [])
        self.DrawRightPanel()
        return

    def DoTryBuyItem(self, idx):
        print 'DoTryBuyItem', idx
        if idx >= len(self.mRecentItemList):
            return
        itemId = self.mRecentItemList[idx]
        self.mClientSystem.OnOpenSingleItemPop(self.mDiamond, self.mPoints, itemId)
        return

    def OpenSingleItemByName(self, categoryName, ItemName):
        if not categoryName:
            return
        groupId = self.GetGroupIdByName(categoryName)
        if groupId not in self.mGroupToItemList:
            return
        itemList = self.FindItemsByName(ItemName)
        for itemId in itemList:
            if itemId in self.mGroupToItemList[groupId]:
                self.mClientSystem.OnOpenSingleItemPop(self.mDiamond, self.mPoints, itemId)
                return

        return

    @ViewBinder.binding(ViewBinder.BF_EditChanged | ViewBinder.BF_EditFinished)
    def message_text_edit_box(self, args):
        input = args['Text']
        self.mLastInput = input
        if input:
            self.mShowSearchData = True
            self.mRecentItemList = self.FindItemsByName(input)
            self.DrawLeftPanel()
            self.DrawRightPanel()
        else:
            self.mShowSearchData = False
            self.DrawLeftPanel()
            self.mRecentItemList = self.mGroupToItemList.get(self.mSelectGroupId, [])
            self.DrawRightPanel()
        return ViewRequest.Refresh

    def OnButtonClear(self, args):
        print 'OnButtonClear'
        self.mLastInput = ''
        textEditBoxUIControl = self.GetBaseUIControl(self.mTextEditPath).asTextEditBox()
        textEditBoxUIControl.SetEditText('')
        self.mShowSearchData = False
        self.DrawLeftPanel()
        self.mRecentItemList = self.mGroupToItemList.get(self.mSelectGroupId, [])
        self.DrawRightPanel()
        return

    def OnGroupPageChange(self, args):
        line = args['ButtonPath'].split('_')
        idx = int(line[-1])
        self.DoChangeSelectGroupPage(idx)
        return

    def OnClickGoodsBuy(self, args):
        if not self.mIsGoodsMoving:
            line = args['ButtonPath'].split('/')
            line = line[-2].split('_')
            idx = int(line[-1])
            self.DoTryBuyItem(idx)
        return

    def OnClickGoodsPicBuy(self, args):
        if not self.mIsGoodsMoving:
            line = args['ButtonPath'].split('/')
            line = line[-3].split('_')
            idx = int(line[-1])
            self.DoTryBuyItem(idx)
        return

    def OnMoveGoods(self, args):
        self.mIsGoodsMoving = True
        self.mShouldPlayClickSound = False
        return

    def OnMoveInGoods(self, args):
        self.mIsGoodsMoving = True
        self.mShouldPlayClickSound = False
        return

    def OnTouchDownGoods(self, args):
        self.mIsGoodsMoving = False
        self.mShouldPlayClickSound = True
        return

    def OnPlaySoundClientEvent(self, args):
        isUISound = args['pos'] == (0, 0, 0)
        if not self.mShouldPlayClickSound and isUISound:
            args['cancel'] = True
            self.mShouldPlayClickSound = True
            return args
        return

    def OnButtonCancel(self, args):
        self.CloseShop()
        return

    def OnButtonCharge(self, args={}):
        import mod.common.gameConfig as modGameCfg
        if clientApi.GetPlatform() == 0 and not modGameCfg.B_PC_COCOS:
            import gui
            gui.open_pc_charge_gui()
        else:
            import engine_notify_handler
            engine_notify_handler.instance.notify_charge_account()
        return

    def OnButtonUrge(self, args):
        print 'OnButtonUrge', args
        self.mClientSystem.StartForceShipItem()
        self.mUrgeCountdown = 31
        self.SetVisible(self.mButtonUrge, False)
        self.SetVisible(self.mButtonUrgeDisable, True)
        self.DoUrgeTimer()
        if not self.mUrgeTimer:
            comp = clientApi.GetEngineCompFactory().CreateGame(clientApi.GetLevelId())
            self.mUrgeTimer = comp.AddRepeatedTimer(1.0, self.DoUrgeTimer)
        return

    def DoUrgeTimer(self):
        self.mUrgeCountdown -= 1
        if self.mUrgeCountdown >= 0:
            self.SetButtonText(self.mButtonUrgeDisable, '催促发货(%ds)' % self.mUrgeCountdown)
        else:
            self.SetVisible(self.mButtonUrge, True)
            self.SetVisible(self.mButtonUrgeDisable, False)
            self.ReleaseUrgeTimer()
        return

    def ReleaseUrgeTimer(self):
        if self.mUrgeTimer:
            comp = clientApi.GetEngineCompFactory().CreateGame(clientApi.GetLevelId())
            comp.CancelTimer(self.mUrgeTimer)
            self.mUrgeTimer = None
        return

