# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/ui/neteaseShopSingleItemUI.py
import mod.client.extraClientApi as clientApi
ViewBinder = clientApi.GetViewBinderCls()
ViewRequest = clientApi.GetViewViewRequestCls()
from client.neteaseSystem.ui.neteaseShopUIScreenNode import ExtraScreenNode

class ShopSingleItemUIScreen(ExtraScreenNode):

    def __init__(self, namespace, name, param):
        ExtraScreenNode.__init__(self, namespace, name, param)
        self.mItemId = None
        self.mQueryStyle = None
        self.mItemData = {}
        return

    def InitScreen(self):
        self.ChangeScreenVisible(False)
        return

    def Destroy(self):
        return

    def Update(self):
        return

    def Create(self):
        scrollBase = '/main_pnl/pnl_base/img_bg/pnl_content/scroll_desc'
        scrollViewUIControl = self.GetBaseUIControl(scrollBase).asScrollView()
        scrollBase = scrollViewUIControl.GetScrollViewContentPath()
        self.mScrollParent = scrollBase
        self.mItemContent = scrollBase + '/lb_item_content'
        self.AddButtonUpTouchEventHandler('/main_pnl/pnl_base/img_bg/btn_cancel', self.OnButtonCancel)
        self.AddButtonUpTouchEventHandler('/main_pnl/pnl_base/img_bg/btn_buy', self.OnButtonBuy)
        return

    def InitSystem(self, system, nameSpace, systemName):
        ExtraScreenNode.InitSystem(self, system, nameSpace, systemName)
        self.mClientSystem.ListenForEvent(nameSpace, systemName, 'QueryItemDetailResult', self, self.OnQueryItemDetailResult)
        self.mClientSystem.ListenForEvent(nameSpace, systemName, 'QueryMoneyResult', self, self.OnQueryMoneyResult)
        return

    def OnQueryItemDetailResult(self, data):
        if not self.mIsShow:
            return
        if self.mItemId != data['itemId']:
            return
        suc = data['suc']
        if suc:
            itemDetailCache = data['cache']
            self.mItemData = itemDetailCache.mData
            self.DrawItemDetail()
        else:
            self.DrawQueryFail()
        return

    def OnQueryMoneyResult(self, data):
        if not self.mIsShow:
            return
        if not data['suc']:
            return
        moneyData = data['cache']
        self.mDiamond = moneyData.mDiamond
        self.mPoints = moneyData.mPoints
        return

    def GetBuyLimitInfo(self):
        if not self.mItemData:
            return (0, None)
        else:
            limit = self.mItemData.get('buy_limit', 0)
            if limit <= 0:
                return (0, None)
            if limit >= self.MaxBuyLimitNumber:
                return (0, None)
            hasBuy = self.mItemData.get('buy_count', 0)
            return (hasBuy, limit)

    def GetGoodState(self):
        if not self.mItemData:
            return 0
        return self.mItemData.get('goods_state')

    def Show(self, diamond, points, itemId):
        self.mDiamond = diamond
        self.mPoints = points
        self.mItemId = itemId
        self.ChangeScreenVisible(True)
        itemDetailCache = self.mClientSystem.GetShopCache().GetItemDetail(itemId)
        if itemDetailCache is None:
            self.DrawWaiting()
        else:
            self.mItemData = itemDetailCache.mData
            self.DrawItemDetail()
        return

    def DrawItemDetail(self):
        self.mQueryStyle = 'success'
        self.SetText('/main_pnl/pnl_base/img_bg/lb_title', '详情')
        self.SetVisible('/main_pnl/pnl_base/img_bg/pnl_content', True)
        self.DrawItemPic()
        self.DrawItemPrice()
        self.DrawOverview()
        self.DrawBuyButton()
        return

    def DrawWaiting(self):
        self.mQueryStyle = 'waiting'
        self.SetText('/main_pnl/pnl_base/img_bg/lb_title', '正在获取道具详情...')
        self.SetVisible('/main_pnl/pnl_base/img_bg/pnl_content', False)
        self.SetButtonText('/main_pnl/pnl_base/img_bg/btn_buy', '关闭')
        return

    def DrawQueryFail(self):
        self.mQueryStyle = 'fail'
        self.SetText('/main_pnl/pnl_base/img_bg/lb_title', '获取道具详情失败！')
        self.SetVisible('/main_pnl/pnl_base/img_bg/pnl_content', False)
        self.SetButtonText('/main_pnl/pnl_base/img_bg/btn_buy', '重试')
        return

    def DrawItemPic(self):
        extras = self.mItemData.get('extras', {})
        is_first_charge = int(extras.get('is_first_charge', 0))
        user_first_charge = int(extras.get('user_first_charge', 0))
        if is_first_charge and not user_first_charge:
            url = extras.get('first_charge_img', '')
        else:
            url = self.mItemData.get('image_url', '')
        imageUIControl = self.GetBaseUIControl('/main_pnl/pnl_base/img_bg/pnl_content/img_item_pic').asImage()
        import clienthttp
        clienthttp.HttpPool().RequestFile(url, imageUIControl._callbackSpriteStore)
        return

    def DrawItemPrice(self):
        basePath = '/main_pnl/pnl_base/img_bg/pnl_content'
        imgPath = basePath + '/img_diamond_icon'
        diamond = self.mItemData.get('diamond', 0)
        if diamond > 0:
            self.SetSprite(imgPath, 'textures/ui/netease_shop/icon_prize01.png')
            realPrice = diamond
        else:
            self.SetSprite(imgPath, 'textures/ui/netease_shop/icon_prize02.png')
            realPrice = self.mItemData.get('points', 0)
        self.SetText(basePath + '/lb_price', str(realPrice))
        discount = self.mItemData.get('discount', 100)
        if discount >= 100 or discount == 0:
            self.SetVisible(basePath + '/pnl_dicount', False)
            return
        self.SetVisible(basePath + '/pnl_dicount', True)
        fakePrice = int(realPrice * 100.0 / discount)
        self.SetText(basePath + '/pnl_dicount/lb_discount_percent', ('特惠:-{}%%').format(100 - discount))
        self.SetText(basePath + '/pnl_dicount/lb_discount_org', str(fakePrice))
        return

    def DrawOverview(self):
        basePath = '/main_pnl/pnl_base/img_bg/pnl_content'
        name = self.mItemData.get('name', '')
        self.SetText(basePath + '/lb_item_name', name)
        desc = self.mItemData.get('info', '')
        self.SetText(self.mItemContent, desc, syncSize=True)
        size = self.GetSize(self.mItemContent)
        self.SetSize(self.mScrollParent, size)
        return

    def DrawBuyButton(self):
        hasBuy, limit = self.GetBuyLimitInfo()
        if not limit:
            self.SetButtonText('/main_pnl/pnl_base/img_bg/btn_buy', '购买')
        else:
            canbuy = max(0, limit - hasBuy)
            self.SetButtonText('/main_pnl/pnl_base/img_bg/btn_buy', '购买(%d/%d)' % (canbuy, limit))
        if self.GetGoodState() == 0:
            self.SetButtonText('/main_pnl/pnl_base/img_bg/btn_buy', '非卖品')
            basePath = '/main_pnl/pnl_base/img_bg/btn_buy'
            self.SetSprite(basePath + '/default', 'textures/ui/netease_shop/btn01_select')
            self.SetSprite(basePath + '/hover', 'textures/ui/netease_shop/btn01_select')
            self.SetSprite(basePath + '/pressed', 'textures/ui/netease_shop/btn01_select')
            self.SetTouchEnable(basePath, False)
        else:
            basePath = '/main_pnl/pnl_base/img_bg/btn_buy'
            self.SetSprite(basePath + '/default', 'textures/ui/netease_shop/btn01')
            self.SetSprite(basePath + '/hover', 'textures/ui/netease_shop/btn01_hover')
            self.SetSprite(basePath + '/pressed', 'textures/ui/netease_shop/btn01_click')
            self.SetTouchEnable(basePath, True)
        return

    def OnButtonCancel(self, args):
        self.ChangeScreenVisible(False)
        return

    def OnButtonBuy(self, args):
        if self.mQueryStyle == 'waiting':
            self.ChangeScreenVisible(False)
        elif self.mQueryStyle == 'fail':
            itemDetailCache = self.mClientSystem.GetShopCache().GetItemDetail(self.mItemId)
            if itemDetailCache is None:
                self.DrawWaiting()
            else:
                self.mItemData = itemDetailCache.mData
                self.DrawItemDetail()
        elif self.mQueryStyle == 'success':
            self.OnRealBuy()
        return

    def OnRealBuy(self):
        self.ChangeScreenVisible(False)
        hasBuy, limit = self.GetBuyLimitInfo()
        if limit:
            canbuy = max(0, limit - hasBuy)
            if canbuy <= 0:
                self.mClientSystem.ShowConfirmPop('提示', '购买次数不足')
                return
        diamond = self.mItemData.get('diamond', 0)
        if diamond > 0:
            if self.mDiamond < diamond:
                self.mClientSystem.ShowChargeHint()
                return
        else:
            points = self.mItemData.get('points', 0)
            if self.mPoints < points:
                self.mClientSystem.ShowConfirmPop('提示', '剩余货币不足')
                return
        if limit:
            alreadyBuy = hasBuy + 1
        else:
            alreadyBuy = -1
        self.mClientSystem.StartBuyItem(alreadyBuy, self.mItemId)
        return
