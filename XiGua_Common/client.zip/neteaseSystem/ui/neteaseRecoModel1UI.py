# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/ui/neteaseRecoModel1UI.py
import mod.client.extraClientApi as clientApi
ViewBinder = clientApi.GetViewBinderCls()
ViewRequest = clientApi.GetViewViewRequestCls()
from client.neteaseSystem.ui.neteaseShopUIScreenNode import ExtraScreenNode

class ShopRecoModel1UIScreen(ExtraScreenNode):

    def __init__(self, namespace, name, param):
        ExtraScreenNode.__init__(self, namespace, name, param)
        self.mItemId = None
        self.mDesc = ''
        self.mCloseAfterBuy = False
        self.mDiamond = 0
        self.mPoints = 0
        self.mItemData = {}
        return

    def InitScreen(self):
        self.ChangeScreenVisible(False)
        return

    def Destroy(self):
        return

    def Update(self):
        return

    def Create(self):
        mainBase = '/variables_button_mappings_and_controls/safezone_screen_matrix/inner_matrix/safezone_screen_panel/root_screen_panel'
        scrollBase = mainBase + '/main_pnl/img_bg/pnl_content/scroll_desc'
        scrollViewUIControl = self.GetBaseUIControl(scrollBase).asScrollView()
        scrollBase = scrollViewUIControl.GetScrollViewContentPath()
        self.mScrollParent = scrollBase
        self.mItemContent = scrollBase + '/lb_desc'
        self.AddButtonUpTouchEventHandler(mainBase + '/main_pnl/img_bg/btn_close', self.OnButtonCancel)
        self.AddButtonUpTouchEventHandler(mainBase + '/main_pnl/img_bg/pnl_content/pnl_buy/btn_buy', self.OnButtonBuy)
        self.mPicPath = mainBase + '/main_pnl/img_bg/pnl_content/img_pic'
        self.mLimitNumPath = mainBase + '/main_pnl/img_bg/pnl_content/lb_limit_num'
        self.mLoadingPath = mainBase + '/main_pnl/img_bg/pnl_content/pnl_buy/img_loading'
        self.mButtonBuyPath = mainBase + '/main_pnl/img_bg/pnl_content/pnl_buy/btn_buy'
        return

    def InitSystem(self, system, nameSpace, systemName):
        ExtraScreenNode.InitSystem(self, system, nameSpace, systemName)
        self.mClientSystem.ListenForEvent(nameSpace, systemName, 'QueryItemDetailResult', self, self.OnQueryItemDetailResult)
        self.mClientSystem.ListenForEvent(nameSpace, systemName, 'QueryMoneyResult', self, self.OnQueryMoneyResult)
        self.mClientSystem.ListenForEvent(nameSpace, systemName, 'BuyItemPaySuccessEvent', self, self.OnBuyItemPaySuccess)
        return

    def OnQueryItemDetailResult(self, data):
        if not self.mIsShow:
            return
        if self.mItemId != data['itemId']:
            return
        suc = data['suc']
        if suc:
            itemDetailCache = data['cache']
            self.mItemData = itemDetailCache.mData
            self.DrawItemDetail()
        else:
            self.DrawQueryFail()
        return

    def OnQueryMoneyResult(self, data):
        if not self.mIsShow:
            return
        if not data['suc']:
            return
        moneyData = data['cache']
        self.mDiamond = moneyData.mDiamond
        self.mPoints = moneyData.mPoints
        return

    def OnBuyItemPaySuccess(self, data):
        if not self.mIsShow:
            return
        if self.mItemId != data['itemId']:
            return
        if self.mCloseAfterBuy:
            self.ChangeScreenVisible(False)
        return

    def GetBuyLimitInfo(self):
        if not self.mItemData:
            return (0, None)
        else:
            limit = self.mItemData.get('buy_limit', 0)
            if limit <= 0:
                return (0, None)
            if limit >= self.MaxBuyLimitNumber:
                return (0, None)
            hasBuy = self.mItemData.get('buy_count', 0)
            return (hasBuy, limit)

    def Show(self, itemId, image, desc, closeAfterBuy):
        self.mItemId = itemId
        self.mDesc = desc
        self.mCloseAfterBuy = closeAfterBuy
        self.ChangeScreenVisible(True)
        self.SetSprite(self.mPicPath, image)
        moneyData = self.mClientSystem.GetShopCache().GetMoneyData()
        if moneyData:
            self.mDiamond = moneyData.mDiamond
            self.mPoints = moneyData.mPoints
        else:
            self.mDiamond = 0
            self.mPoints = 0
        itemDetailCache = self.mClientSystem.GetShopCache().GetItemDetail(itemId)
        if itemDetailCache is None:
            self.DrawWaiting()
        else:
            self.mItemData = itemDetailCache.mData
            self.DrawItemDetail()
        return

    def DrawItemDetail(self):
        self.mQueryStyle = 'success'
        if self.mDesc:
            desc = self.mDesc
        else:
            desc = self.mItemData.get('info', '')
        self.SetText(self.mItemContent, desc, syncSize=True)
        size = self.GetSize(self.mItemContent)
        self.SetSize(self.mScrollParent, size)
        hasBuy, limit = self.GetBuyLimitInfo()
        if not limit:
            self.SetText(self.mLimitNumPath, '')
        else:
            canbuy = max(0, limit - hasBuy)
            self.SetText(self.mLimitNumPath, '  限购(%d/%d)' % (canbuy, limit))
        self.DrawItemPrice()
        return

    def DrawWaiting(self):
        self.mQueryStyle = 'waiting'
        self.SetVisible(self.mLoadingPath, True)
        self.SetVisible(self.mButtonBuyPath, False)
        self.SetText(self.mLoadingPath + '/lb_loading_desc', '购买价格加载中...')
        self.SetText(self.mItemContent, '')
        self.SetText(self.mLimitNumPath, '')
        return

    def DrawQueryFail(self):
        self.mQueryStyle = 'fail'
        self.SetVisible(self.mLoadingPath, True)
        self.SetVisible(self.mButtonBuyPath, False)
        self.SetText(self.mLoadingPath + '/lb_loading_desc', '获取道具信息失败')
        self.SetText(self.mItemContent, '')
        self.SetText(self.mLimitNumPath, '')
        return

    def DrawItemPrice(self):
        basePath = self.mButtonBuyPath
        self.SetVisible(basePath, True)
        self.SetVisible(self.mLoadingPath, False)
        diamond = self.mItemData.get('diamond', 0)
        if diamond > 0:
            image = 'textures/ui/netease_shop/icon_prize01.png'
            realPrice = diamond
        else:
            image = 'textures/ui/netease_shop/icon_prize02.png'
            realPrice = self.mItemData.get('points', 0)
        discount = self.mItemData.get('discount', 100)
        if discount >= 100:
            self.SetVisible(basePath + '/pnl_price_normal', True)
            self.SetVisible(basePath + '/pnl_price_discount', False)
            basePath = basePath + '/pnl_price_normal'
            self.SetSprite(basePath + '/img_price_normal_icon', image)
            self.SetText(basePath + '/lb_price_normal', str(realPrice))
        else:
            self.SetVisible(basePath + '/pnl_price_normal', False)
            self.SetVisible(basePath + '/pnl_price_discount', True)
            basePath = basePath + '/pnl_price_discount'
            self.SetSprite(basePath + '/img_price_discount_icon', image)
            self.SetText(basePath + '/lb_price_discount', str(realPrice))
            fakePrice = int(realPrice * 100.0 / discount)
            self.SetText(basePath + '/lb_price_discount_org', str(fakePrice))
            self.SetText(basePath + '/img_price_discount_bg/lb_price_discount_percent', ('-{}%%').format(100 - discount))
        return

    def OnButtonCancel(self, args):
        self.ChangeScreenVisible(False)
        return

    def OnButtonBuy(self, args):
        if self.mQueryStyle == 'waiting':
            self.ChangeScreenVisible(False)
        elif self.mQueryStyle == 'fail':
            self.ChangeScreenVisible(False)
        elif self.mQueryStyle == 'success':
            self.OnRealBuy()
        return

    def OnRealBuy(self):
        hasBuy, limit = self.GetBuyLimitInfo()
        if limit:
            canbuy = max(0, limit - hasBuy)
            if canbuy <= 0:
                self.ChangeScreenVisible(False)
                self.mClientSystem.ShowConfirmPop('提示', '购买次数不足')
                return
        diamond = self.mItemData.get('diamond', 0)
        if diamond > 0:
            if self.mDiamond < diamond:
                self.mClientSystem.ShowChargeHint()
                return
        else:
            points = self.mItemData.get('points', 0)
            if self.mPoints < points:
                self.mClientSystem.ShowConfirmPop('提示', '剩余货币不足')
                return
        if limit:
            alreadyBuy = hasBuy + 1
        else:
            alreadyBuy = -1

        def okCallback():
            self.mClientSystem.StartBuyItem(alreadyBuy, self.mItemId)
            return

        self.mClientSystem.ShowFreeAsking('提示', '购买该商品？', '购买', okCallback)
        return
