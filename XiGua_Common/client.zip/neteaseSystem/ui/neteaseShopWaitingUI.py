# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/ui/neteaseShopWaitingUI.py
import time, mod.client.extraClientApi as clientApi
ViewBinder = clientApi.GetViewBinderCls()
ViewRequest = clientApi.GetViewViewRequestCls()
from mod_log import engine_logger as logger
from client.neteaseSystem.ui.neteaseShopUIScreenNode import ExtraScreenNode

class ShopWaitingUIScreen(ExtraScreenNode):

    def __init__(self, namespace, name, param):
        ExtraScreenNode.__init__(self, namespace, name, param)
        return

    def InitScreen(self):
        self.ChangeScreenVisible(False)
        return

    def Destroy(self):
        return

    def Update(self):
        return

    def Create(self):
        return

    def ShowBuyItemWaiting(self):
        self.ChangeScreenVisible(True)
        self.SetText('/main_pnl/pnl_bg/img_bg/lb_title', '提示')
        self.SetText('/main_pnl/pnl_bg/img_bg/lb_content', '商品购买中，请稍后…')
        return

    def HideBuyItemWaiting(self):
        self.ChangeScreenVisible(False)
        return
