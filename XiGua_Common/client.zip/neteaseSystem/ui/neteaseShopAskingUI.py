# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/ui/neteaseShopAskingUI.py
import mod.client.extraClientApi as clientApi
ViewBinder = clientApi.GetViewBinderCls()
ViewRequest = clientApi.GetViewViewRequestCls()
from client.neteaseSystem.ui.neteaseShopUIScreenNode import ExtraScreenNode

class ShopAskingUIScreen(ExtraScreenNode):

    def __init__(self, namespace, name, param):
        ExtraScreenNode.__init__(self, namespace, name, param)
        self.mOkCb = None
        self.mCancelCb = None
        return

    def InitScreen(self):
        self.ChangeScreenVisible(False)
        return

    def Destroy(self):
        return

    def Update(self):
        return

    def Create(self):
        self.AddButtonUpTouchEventHandler('/main_pnl/pnl_base/img_bg/btn_cancel', self.OnButtonCancel)
        self.AddButtonUpTouchEventHandler('/main_pnl/pnl_base/img_bg/btn_ok', self.OnButtonOk)
        return

    def Show(self, title, desc, okText='', okCallback=None, cancelText='', cancelCallback=None):
        self.ChangeScreenVisible(True)
        self.SetText('/main_pnl/pnl_base/img_bg/lb_title', title)
        self.SetText('/main_pnl/pnl_base/img_bg/lb_content', desc)
        if not cancelText:
            cancelText = '取消'
        self.SetText('/main_pnl/pnl_base/img_bg/btn_cancel/button_label', cancelText)
        if not okText:
            okText = '确定'
        self.SetText('/main_pnl/pnl_base/img_bg/btn_ok/button_label', okText)
        self.mOkCb = okCallback
        self.mCancelCb = cancelCallback
        return

    def ShowCharge(self):
        self.ChangeScreenVisible(True)
        self.SetText('/main_pnl/pnl_base/img_bg/lb_title', '提示')
        self.SetText('/main_pnl/pnl_base/img_bg/lb_content', '余额不足，请前往充值')
        self.SetText('/main_pnl/pnl_base/img_bg/btn_cancel/button_label', '取消')
        self.SetText('/main_pnl/pnl_base/img_bg/btn_ok/button_label', '前往充值')
        self.mOkCb = self.OnGotoCharge
        self.mCancelCb = None
        return

    def OnGotoCharge(self):
        import common.gameConfig as modGameCfg
        if clientApi.GetPlatform() == 0 and not modGameCfg.B_PC_COCOS:
            import gui
            gui.open_pc_charge_gui()
        else:
            import engine_notify_handler
            engine_notify_handler.instance.notify_charge_account()
        return

    def OnButtonCancel(self, args):
        self.ChangeScreenVisible(False)
        callback = self.mCancelCb
        self.mCancelCb = None
        if callback and callable(callback):
            callback()
        return

    def OnButtonOk(self, args):
        self.ChangeScreenVisible(False)
        callback = self.mOkCb
        self.mOkCb = None
        if callback and callable(callback):
            callback()
        return
