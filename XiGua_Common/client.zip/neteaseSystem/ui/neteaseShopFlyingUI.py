# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/ui/neteaseShopFlyingUI.py
import time, mod.client.extraClientApi as clientApi
ViewBinder = clientApi.GetViewBinderCls()
ViewRequest = clientApi.GetViewViewRequestCls()
from mod_log import engine_logger as logger
from client.neteaseSystem.ui.neteaseShopUIScreenNode import ExtraScreenNode

class ShopFlyingUIScreen(ExtraScreenNode):

    def __init__(self, namespace, name, param):
        ExtraScreenNode.__init__(self, namespace, name, param)
        self.mUpdateTimer = None
        return

    def InitScreen(self):
        self.ChangeScreenVisible(False)
        return

    def Destroy(self):
        return

    def Update(self):
        return

    def ChangeScreenVisible(self, flag):
        ExtraScreenNode.ChangeScreenVisible(self, flag)
        if flag:
            if not self.mUpdateTimer:
                comp = clientApi.GetEngineCompFactory().CreateGame(clientApi.GetLevelId())
                self.mUpdateTimer = comp.AddRepeatedTimer(1.0, self.DoUpdateParts)
        elif self.mUpdateTimer:
            comp = clientApi.GetEngineCompFactory().CreateGame(clientApi.GetLevelId())
            comp.CancelTimer(self.mUpdateTimer)
            self.mUpdateTimer = None
        return

    def Create(self):
        self.SetNeedChangeHud(False)
        self.mViewParent = '/main_pnl/pnl_base'
        self.mViewBase = '/main_pnl/pnl_base/img_fly_base'
        self.mViewBasePos = self.GetPosition(self.mViewBase)
        self.mViewBaseSize = self.GetSize(self.mViewBase)
        self.SetVisible(self.mViewBase, False)
        self.mMaxUsedId = 0
        self.mViewPartDict = {}
        self.mFreeParts = set()
        self.mActiveParts = {}
        return

    def GetUniqueId(self):
        self.mMaxUsedId += 1
        return self.mMaxUsedId

    def FindPosByIndex(self, index):
        x = self.mViewBasePos[0]
        if index % 2 == 0:
            offset = index // 2
            y = self.mViewBasePos[1] + (self.mViewBaseSize[1] + 2) * offset
        else:
            offset = (index + 1) // 2
            y = self.mViewBasePos[1] - (self.mViewBaseSize[1] + 2) * offset
        return (
         x, y)

    def FindFreePosIndex(self):
        for i in xrange(10):
            if i in self.mActiveParts:
                continue
            return i

        return

    def GetFreeViewPart(self):
        if self.mFreeParts:
            id = self.mFreeParts.pop()
            return id
        id = self.GetUniqueId()
        newName = 'img_fly_part_%d' % id
        self.Clone(self.mViewBase, self.mViewParent, newName)
        fullName = '%s/%s' % (self.mViewParent, newName)
        self.mViewPartDict[id] = fullName
        return id

    def GiveBackViewPart(self, id):
        part = self.mViewPartDict[id]
        self.SetVisible(part, False)
        self.mFreeParts.add(id)
        return

    def DoUpdateParts(self):
        if not self.mActiveParts:
            self.ChangeScreenVisible(False)
            return
        now = time.time()
        needRemoveParts = []
        for data in self.mActiveParts.itervalues():
            if data['endTp'] >= now:
                needRemoveParts.append(data)

        for data in needRemoveParts:
            del self.mActiveParts[data['index']]
            self.GiveBackViewPart(data['id'])

        return

    def ShowOne(self, text='', sec=5):
        if not text:
            text = '未查询到商品到账'
        id = self.GetFreeViewPart()
        part = self.mViewPartDict[id]
        self.SetVisible(part, True)
        self.SetVisible('%s/lb_line_two' % part, False)
        self.SetVisible('%s/lb_line_one' % part, True)
        self.SetText('%s/lb_line_one/' % part, text)
        self.DrawSinglePart(id, part, sec)
        return

    def ShowTwo(self, head, tail='', sec=5):
        if not tail:
            tail = '已到账成功'
        id = self.GetFreeViewPart()
        part = self.mViewPartDict[id]
        self.SetVisible(part, True)
        self.SetVisible('%s/lb_line_two' % part, True)
        self.SetVisible('%s/lb_line_one' % part, False)
        self.SetText('%s/lb_line_two' % part, head)
        self.SetText('%s/lb_line_two/lb_line_two_tail' % part, tail)
        self.DrawSinglePart(id, part, sec)
        return

    def DrawSinglePart(self, id, part, sec):
        index = self.FindFreePosIndex()
        if index is None:
            logger.error('DrawSinglePart failed, cannot find pos')
            self.GiveBackViewPart(id)
            return
        else:
            pos = self.FindPosByIndex(index)
            self.SetPosition(part, pos)
            self.mActiveParts[index] = {'index': index, 
               'part': part, 
               'id': id, 
               'endTp': (time.time() + sec)}
            self.ChangeScreenVisible(True)
            return
