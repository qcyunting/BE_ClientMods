# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/ui/neteaseShopUIDef.py
import mod.client.extraClientApi as clientApi

class UIDef:
    UIShopAsking = 'UIShopAsking'
    UIShopConfirm = 'UIShopConfirm'
    UIShopFlying = 'UIShopFlying'
    UIShopWaiting = 'UIShopWaiting'
    UIShopSingleItem = 'UIShopSingleItem'
    UIShopMain = 'UIShopMain'
    UIShopRecoModel1 = 'UIShopRecoModel1'
    UIShopRecoModel2 = 'UIShopRecoModel2'
    UIShopDesk = 'UIShopDesk'


UIData = {(UIDef.UIShopDesk): {'cls': 'client.neteaseSystem.ui.neteaseShopDeskUI.ShopDeskUIScreen', 
                        'screen': 'netease_shop_desk.main', 
                        'isHud': 1}, 
   (UIDef.UIShopAsking): {'cls': 'client.neteaseSystem.ui.neteaseShopAskingUI.ShopAskingUIScreen', 
                          'screen': 'netease_shop_asking.main', 
                          'isHud': 1, 
                          'layer': (clientApi.GetMinecraftEnum().UiBaseLayer.PopUpModal)}, 
   (UIDef.UIShopConfirm): {'cls': 'client.neteaseSystem.ui.neteaseShopConfirmUI.ShopConfirmUIScreen', 
                           'screen': 'netease_shop_confirm.main', 
                           'isHud': 1, 
                           'layer': (clientApi.GetMinecraftEnum().UiBaseLayer.PopUpModal)}, 
   (UIDef.UIShopFlying): {'cls': 'client.neteaseSystem.ui.neteaseShopFlyingUI.ShopFlyingUIScreen', 
                          'screen': 'netease_shop_flying.main', 
                          'isHud': 1}, 
   (UIDef.UIShopWaiting): {'cls': 'client.neteaseSystem.ui.neteaseShopWaitingUI.ShopWaitingUIScreen', 
                           'screen': 'netease_shop_waiting.main', 
                           'isHud': 1, 
                           'layer': (clientApi.GetMinecraftEnum().UiBaseLayer.PopUpModal)}, 
   (UIDef.UIShopSingleItem): {'cls': 'client.neteaseSystem.ui.neteaseShopSingleItemUI.ShopSingleItemUIScreen', 
                              'screen': 'netease_shop_item_pop.main', 
                              'isHud': 1, 
                              'layer': (clientApi.GetMinecraftEnum().UiBaseLayer.PopUpLv2)}, 
   (UIDef.UIShopMain): {'cls': 'client.neteaseSystem.ui.netease_shop_main.ShopMainUIScreen', 
                        'screen': 'netease_shop_main1.main', 
                        'isHud': 1, 
                        'layer': (clientApi.GetMinecraftEnum().UiBaseLayer.PopUpLv1)}, 
   (UIDef.UIShopRecoModel1): {'cls': 'client.neteaseSystem.ui.neteaseRecoModel1UI.ShopRecoModel1UIScreen', 
                              'screen': 'netease_shop_recommend_model1.main', 
                              'isHud': 1, 
                              'layer': (clientApi.GetMinecraftEnum().UiBaseLayer.PopUpLv2)}, 
   (UIDef.UIShopRecoModel2): {'cls': 'client.neteaseSystem.ui.neteaseRecoModel2UI.ShopRecoModel2UIScreen', 
                              'screen': 'netease_shop_recommend_model2.main', 
                              'isHud': 1, 
                              'layer': (clientApi.GetMinecraftEnum().UiBaseLayer.PopUpLv2)}}

class newUIDef:
    UIShopAsking = 'newUIShopAsking'
    UIShopConfirm = 'newUIShopConfirm'
    UIShopFlying = 'newUIShopFlying'
    UIShopWaiting = 'newUIShopWaiting'
    UIShopSingleItem = 'newUIShopSingleItem'
    UIShopMain = 'newUIShopMain'
    UIShopRecoModel1 = 'newUIShopRecoModel1'
    UIShopRecoModel2 = 'newUIShopRecoModel2'
    UIShopDesk = 'newUIShopDesk'


newUIData = {(newUIDef.UIShopDesk): {'cls': 'client.neteaseSystem.ui.neteaseShopDeskUI.ShopDeskUIScreen', 
                           'screen': 'new_netease_shop_desk.main', 
                           'isHud': 1}, 
   (newUIDef.UIShopAsking): {'cls': 'client.neteaseSystem.ui.neteaseShopAskingUI.ShopAskingUIScreen', 
                             'screen': 'new_netease_shop_asking.main', 
                             'isHud': 1, 
                             'layer': (clientApi.GetMinecraftEnum().UiBaseLayer.PopUpModal)}, 
   (newUIDef.UIShopConfirm): {'cls': 'client.neteaseSystem.ui.neteaseShopConfirmUI.ShopConfirmUIScreen', 
                              'screen': 'new_netease_shop_confirm.main', 
                              'isHud': 1, 
                              'layer': (clientApi.GetMinecraftEnum().UiBaseLayer.PopUpModal)}, 
   (newUIDef.UIShopFlying): {'cls': 'client.neteaseSystem.ui.neteaseShopFlyingUI.ShopFlyingUIScreen', 
                             'screen': 'new_netease_shop_flying.main', 
                             'isHud': 1}, 
   (newUIDef.UIShopWaiting): {'cls': 'client.neteaseSystem.ui.neteaseShopWaitingUI.ShopWaitingUIScreen', 
                              'screen': 'new_netease_shop_waiting.main', 
                              'isHud': 1, 
                              'layer': (clientApi.GetMinecraftEnum().UiBaseLayer.PopUpModal)}, 
   (newUIDef.UIShopSingleItem): {'cls': 'client.neteaseSystem.ui.neteaseShopSingleItemUI.ShopSingleItemUIScreen', 
                                 'screen': 'new_netease_shop_item_pop.main', 
                                 'isHud': 1, 
                                 'layer': (clientApi.GetMinecraftEnum().UiBaseLayer.PopUpLv2)}, 
   (newUIDef.UIShopMain): {'cls': 'client.neteaseSystem.ui.netease_shop_main.ShopMainUIScreen', 
                           'screen': 'new_netease_shop_main1.main', 
                           'isHud': 1, 
                           'layer': (clientApi.GetMinecraftEnum().UiBaseLayer.PopUpLv1)}, 
   (newUIDef.UIShopRecoModel1): {'cls': 'client.neteaseSystem.ui.neteaseRecoModel1UI.ShopRecoModel1UIScreen', 
                                 'screen': 'new_netease_shop_recommend_model1.main', 
                                 'isHud': 1, 
                                 'layer': (clientApi.GetMinecraftEnum().UiBaseLayer.PopUpLv2)}, 
   (newUIDef.UIShopRecoModel2): {'cls': 'client.neteaseSystem.ui.neteaseRecoModel2UI.ShopRecoModel2UIScreen', 
                                 'screen': 'new_netease_shop_recommend_model2.main', 
                                 'isHud': 1, 
                                 'layer': (clientApi.GetMinecraftEnum().UiBaseLayer.PopUpLv2)}}
