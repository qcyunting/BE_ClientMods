# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/ui/neteaseShopUIScreenNode.py
import mod.client.extraClientApi as clientApi
ScreenNode = clientApi.GetScreenNodeCls()

class ExtraScreenNode(ScreenNode):
    MaxBuyLimitNumber = 10000000

    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.mUiKey = None
        self.mUiMgr = None
        self.mIsShow = False
        self.mClientSystem = None
        self.mNeedChangeHud = True
        return

    def InitSystem(self, system, nameSpace, systemName):
        self.mClientSystem = system
        return

    def SetNeedChangeHud(self, flag):
        self.mNeedChangeHud = flag
        return

    def SetUiKey(self, uiKey, uiMgr):
        self.mUiKey = uiKey
        self.mUiMgr = uiMgr
        return

    def IsVisible(self):
        return self.mIsShow

    def ChangeScreenVisible(self, flag):
        self.SetScreenVisible(flag)
        self.mIsShow = flag
        if not self.mNeedChangeHud:
            return
        if self.mUiMgr and self.mUiKey:
            if flag:
                self.mUiMgr.RegisterUIOpen(self.mUiKey)
                self.SetIsHud(0)
            else:
                isEmpty = self.mUiMgr.RegisterUIClose(self.mUiKey)
                if isEmpty:
                    self.SetIsHud(1)
        return

    def SetVisible(self, path, isVisible):
        baseUIControl = self.GetBaseUIControl(path)
        return baseUIControl.SetVisible(isVisible)

    def GetVisible(self, path):
        baseUIControl = self.GetBaseUIControl(path)
        return baseUIControl.GetVisible()

    def SetPosition(self, path, pos):
        baseUIControl = self.GetBaseUIControl(path)
        return baseUIControl.SetPosition(pos)

    def GetPosition(self, path):
        baseUIControl = self.GetBaseUIControl(path)
        return baseUIControl.GetPosition()

    def SetSize(self, path, size, resizeChildren=False):
        baseUIControl = self.GetBaseUIControl(path)
        return baseUIControl.SetSize(size, resizeChildren)

    def GetSize(self, path):
        baseUIControl = self.GetBaseUIControl(path)
        if not baseUIControl:
            return None
        else:
            return baseUIControl.GetSize()

    def SetAlpha(self, alpha):
        baseUIControl = self.GetBaseUIControl(path)
        return baseUIControl.SetAlpha(alpha)

    def SetLayer(self, path, layer, syncRefresh=True, forceUpdtae=True):
        baseUIControl = self.GetBaseUIControl(path)
        return baseUIControl.SetLayer(layer, syncRefresh, forceUpdtae)

    def SetTouchEnable(self, path, enable):
        baseUIControl = self.GetBaseUIControl(path)
        return baseUIControl.SetTouchEnable(enable)

    def AddButtonUpTouchEventHandler(self, path, func):
        buttonUIControl = self.GetBaseUIControl(path).asButton()
        buttonUIControl.AddTouchEventParams({'isSwallow': True})
        buttonUIControl.SetButtonTouchUpCallback(func)
        return

    def AddButtonDownTouchEventHandler(self, path, func):
        buttonUIControl = self.GetBaseUIControl(path).asButton()
        buttonUIControl.AddTouchEventParams({'isSwallow': True})
        buttonUIControl.SetButtonTouchDownCallback(func)
        return

    def SetButtonText(self, path, text):
        labelPath = path + '/button_label'
        labelUIControl = self.GetBaseUIControl(labelPath).asLabel()
        return labelUIControl.SetText(text)

    def SetText(self, path, text, syncSize=False):
        labelUIControl = self.GetBaseUIControl(path).asLabel()
        return labelUIControl.SetText(text, syncSize)

    def GetText(self, path):
        labelUIControl = self.GetBaseUIControl(path).asLabel()
        return labelUIControl.GetText()

    def SetTextColor(self, path, color):
        labelUIControl = self.GetBaseUIControl(path).asLabel()
        return labelUIControl.SetTextColor(color)

    def GetTextColor(self, path):
        labelUIControl = self.GetBaseUIControl(path).asLabel()
        return labelUIControl.GetTextColor()

    def SetSprite(self, path, texturePath):
        imageUIControl = self.GetBaseUIControl(path).asImage()
        return imageUIControl.SetSprite(texturePath)


def GetPosition_newVersi0n():
    return

