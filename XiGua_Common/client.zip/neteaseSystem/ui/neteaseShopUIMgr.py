# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/ui/neteaseShopUIMgr.py
import mod.client.extraClientApi as clientApi, client.neteaseSystem.ui.neteaseShopUIDef as uiDef

class UIMgr(object):
    """
        领地管理器
        """

    def __init__(self):
        super(UIMgr, self).__init__()
        self.mOpenedUI = set()
        self.mUIDict = {}
        self.mClientSystem = None
        self.mNameSpace = ''
        self.mSystemName = ''
        return

    def Destroy(self):
        return

    def Init(self, system, uiData, nameSpace, systemName):
        self.mClientSystem = system
        self.mNameSpace = nameSpace
        self.mSystemName = systemName
        for uiKey, config in uiData.iteritems():
            self.InitSingleUI(uiKey, config)

        return

    def InitSingleUI(self, uiKey, config):
        cls, screen = config['cls'], config['screen']
        clientApi.RegisterUI(self.mNameSpace, uiKey, cls, screen)
        extraParam = {}
        if config.has_key('isHud'):
            extraParam['isHud'] = config['isHud']
        extraParam['update_screen'] = False
        extraParam['fresh_async'] = True
        ui = clientApi.CreateUI(self.mNameSpace, uiKey, extraParam)
        if not ui:
            print 'InitSingleUI %s fail' % uiKey
            return
        else:
            layer = config.get('layer', None)
            if layer is not None:
                ui.SetLayer('', layer)
            ui.InitScreen()
            try:
                ui.InitSystem(self.mClientSystem, self.mNameSpace, self.mSystemName)
            except:
                print 'ui %s do not has InitSystem method' % uiKey

            try:
                ui.SetUiKey(uiKey, self)
            except:
                print 'ui %s do not has SetUiKey method' % uiKey

            self.mUIDict[uiKey] = ui
            return

    def GetUI(self, uiKey):
        return self.mUIDict.get(uiKey, None)

    def RemoveUI(self, uiKey):
        ui = self.mUIDict.get(uiKey, None)
        if ui:
            del self.mUIDict[uiKey]
            ui.SetRemove()
            return True
        else:
            return False

    def RegisterUIOpen(self, uiKey):
        self.mOpenedUI.add(uiKey)
        clientApi.SetResponse(False)
        self.SetInputEnable(True)
        return

    def RegisterUIClose(self, uiKey):
        self.mOpenedUI.discard(uiKey)
        if not self.mOpenedUI:
            clientApi.SetResponse(True)
            self.SetInputEnable(False)
            return True
        return False

    def SetInputEnable(self, flag):
        comp = clientApi.GetEngineCompFactory().CreateOperation(clientApi.GetLevelId())
        if flag:
            comp.SetCanPause(False)
            comp.SetCanChat(False)
        else:
            comp.SetCanPause(True)
            comp.SetCanChat(True)
        return
