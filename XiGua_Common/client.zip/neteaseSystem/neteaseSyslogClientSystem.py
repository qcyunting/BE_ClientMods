# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/neteaseSyslogClientSystem.py
import mod.client.extraClientApi as clientApi
from mod_log import engine_logger as logger
ClientSystem = clientApi.GetClientSystemCls()

class neteaseSyslogClientSystem(ClientSystem):

    def __init__(self, namespace, systemName):
        ClientSystem.__init__(self, namespace, systemName)
        self.waitLogin = -1
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'OnScriptTickClient', self, self.onScriptTick)
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'UiInitFinished', self, self.onUiInitFinished)
        self.DefineEvent('SalogDataEvent')
        logger.info('neteaseSyslogClientSystem load')
        return

    def Destroy(self):
        self.UnListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'OnScriptTickClient', self, self.onScriptTick)
        self.UnListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'UiInitFinished', self, self.onUiInitFinished)
        return

    def onScriptTick(self):
        if self.waitLogin >= 0:
            self.waitLogin -= 1
            if self.waitLogin == 0:
                self.sendSalogData()
        return

    def onUiInitFinished(self, data):
        self.waitLogin = 5
        return

    def sendSalogData(self):
        data = self.CreateEventData()
        data['id'] = clientApi.GetLocalPlayerId()
        data['sa_data'] = self.get_sa_log_data()
        self.NotifyToServer('SalogDataEvent', data)
        logger.info('sendSalogData')
        return

    def get_sa_log_data(self):
        import record, setting
        sa_data = {'device_model': (record.get_device_info()), 
           'device_height': (record.get_device_height()), 
           'device_width': (record.get_device_width()), 
           'os_name': (record.get_os_name()), 
           'os_ver': (record.get_os_version()), 
           'imei': '', 
           'location': {}, 'mac_addr': (record.get_mac_address()), 
           'udid': (record.get_machine_code()), 
           'nation': (record.get_nation_code()), 
           'isp': (record.get_network_isp()), 
           'app_channel': (record.get_app_channel()), 
           'app_ver': (record.get_engine_version()), 
           'network': (record.get_network_isp()), 
           'account_id': (setting.get_login_uid())}
        return sa_data


def onScriptTick_newVersi0n():
    return


return
