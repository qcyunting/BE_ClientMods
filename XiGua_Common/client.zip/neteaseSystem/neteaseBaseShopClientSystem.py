# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/neteaseBaseShopClientSystem.py
import time, mod.client.extraClientApi as clientApi
from mod_log import engine_logger as logger
ClientSystem = clientApi.GetClientSystemCls()
import network_proxy
from client.neteaseSystem.neteaseShopCache import ItemShopCache
import client.neteaseSystem.ui.neteaseShopUIMgr as neteaseShopUIMgr, client.neteaseSystem.ui.neteaseShopUIDef as uiDef

class NeteaseBaseShopClientSystem(ClientSystem):

    def __init__(self, namespace, systemName):
        ClientSystem.__init__(self, namespace, systemName)
        self.mUIMgr = neteaseShopUIMgr.UIMgr()
        self.mGameId = None
        self.mIsTestServer = True
        self.mUseCustomShop = True
        self.mUid = None
        self.mPlatformUid = None
        self.mCacheTime = 300
        self.mShopCache = None
        self.mBuyTimer = None
        self.mWaitingShipItem = False
        self.mHasDestroy = False
        self.mOnShopQuerying = False
        self.mWaitingQueryTasks = []
        self.ListenForEngine(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'OnScriptTickClient', self, self.OnScriptTickClient)
        self.ListenForEngine(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'OnBackButtonReleaseClientEvent', self, self.OnCloseShop)
        return

    def Destroy(self):
        self.mHasDestroy = True
        self.StopBuyTimer()
        return

    def GetShopCache(self):
        return self.mShopCache

    def OnBackFromRn(self, routeName):
        print ('OnBackFromRn routeName={}').format(routeName)
        self.mShopCache.GetMoneyData(True)
        return

    def OnScriptTickClient(self, args={}):
        if self.mOnShopQuerying:
            return
        if self.mWaitingQueryTasks:
            func = self.mWaitingQueryTasks.pop(0)
            self.mOnShopQuerying = True
            func()
        return

    def OnShowHint(self, data={}):
        print 'OnShowHint', data
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopFlying)
        if len(data['hint']) == 1:
            ui.ShowOne(data['hint'][0])
        else:
            ui.ShowTwo(data['hint'][0], data['hint'][1])
        return

    def OnOpenShop(self, data):
        print 'OnOpenShop'
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopMain)
        ui.Show(data)
        return

    def OnCloseShop(self, data):
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopMain)
        if ui and ui.IsVisible():
            ui.CloseShop()
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopSingleItem)
        if ui and ui.IsVisible():
            ui.ChangeScreenVisible(False)
        return

    def OnOpenRecoItem(self, data):
        style, itemId, image = data['style'], data['itemId'], data.get('image', 'textures/ui/netease_shop/img01@3x.png')
        desc, closeAfterBuy = data.get('desc', ''), data.get('closeAfterBuy', False)
        if style == 1:
            ui = self.mUIMgr.GetUI(self.UiDef.UIShopRecoModel1)
            ui.Show(itemId, image, desc, closeAfterBuy)
        elif style == 2:
            ui = self.mUIMgr.GetUI(self.UiDef.UIShopRecoModel2)
            ui.Show(itemId, image, closeAfterBuy)
        return

    def OnCloseRecoItem(self, data):
        style = data.get('style', None)
        if style is None:
            ui = self.mUIMgr.GetUI(self.UiDef.UIShopRecoModel1)
            ui.ChangeScreenVisible(False)
            ui = self.mUIMgr.GetUI(self.UiDef.UIShopRecoModel2)
            ui.ChangeScreenVisible(False)
        elif style == 1:
            ui = self.mUIMgr.GetUI(self.UiDef.UIShopRecoModel1)
            ui.ChangeScreenVisible(False)
        elif style == 2:
            ui = self.mUIMgr.GetUI(self.UiDef.UIShopRecoModel2)
            ui.ChangeScreenVisible(False)
        return

    def StartForceShipItem(self):
        return

    def OnOpenSingleItemPop(self, diamond, points, itemId):
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopSingleItem)
        ui.Show(diamond, points, itemId)
        return

    def OpenItemDetailWindow(self, categoryName, itemName):
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopMain)
        ui.Show({'groupName': categoryName, 'itemName': itemName})
        return

    def ShowConfirmPop(self, title, desc):
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopConfirm)
        ui.Show(title, desc)
        return

    def ShowChargeHint(self):
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopAsking)
        ui.ShowCharge()
        return

    def ShowFreeAsking(self, title, desc, okText='', okCallback=None, cancelText='', cancelCallback=None):
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopAsking)
        ui.Show(title, desc, okText, okCallback, cancelText, cancelCallback)
        return

    def ShowBuySuccess(self):
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopConfirm)
        ui.ShowBuySuccess()
        return

    def ShowBuyItemWaiting(self):
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopWaiting)
        ui.ShowBuyItemWaiting()
        return

    def HideBuyItemWaiting(self):
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopWaiting)
        ui.HideBuyItemWaiting()
        return

    def HideShopDesk(self):
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopDesk)
        if not ui:
            self.mIsHideDesk = 1
            return
        ui.HideShopDesk()
        return

    def ShowShopDesk(self):
        ui = self.mUIMgr.GetUI(self.UiDef.UIShopDesk)
        if not ui:
            self.mIsHideDesk = 2
            return
        ui.ShowShopDesk()
        return

    def StartShopQuery(self, func):
        self.mWaitingQueryTasks.append(func)
        return

    def FinishShopQuery(self):
        self.mOnShopQuerying = False
        return self.mHasDestroy

    def StartBuyItem(self, alreadyBuy, itemId, itemNum=1):
        return

    def OnBuyRequestSuc(self, alreadyBuy, itemId, data):
        if data['code'] != 0:
            print ('OnBuyRequestSuc but code error data={}').format(data)
            self.OnBuyRequestFail(data['message'])
            return
        else:
            entity = data.get('entity', None)
            if not entity:
                self.OnBuyRequestFail()
                return
            if self.FinishShopQuery():
                return
            buyType = entity['buy_type']
            orderId = entity['entity_id']

            def querySuc(data):
                self.OnQueryOrderSuc(alreadyBuy, itemId, orderId, buyType, 0, data)
                return

            def queryFail():
                self.OnQueryOrderFail(alreadyBuy, itemId, orderId, buyType, 0)
                return

            def queryFunc():
                network_proxy.store_buy_item_result(orderId, buyType, querySuc, queryFail)
                print ('store_buy_item_result start orderId={} buyType={}').format(orderId, buyType)
                return

            self.StartShopQuery(queryFunc)
            print ('OnBuyRequestSuc buyType={} orderId={}').format(buyType, orderId)
            self.ShowBuyItemWaiting()
            return

    def OnBuyRequestFail(self, message=None):
        if self.FinishShopQuery():
            return
        if not message:
            message = '请求超时'
        print 'OnBuyRequestFail'
        self.HideBuyItemWaiting()
        self.ShowConfirmPop('提示', '购买失败，%s' % message)
        return

    def OnQueryOrderSuc(self, alreadyBuy, itemId, orderId, buyType, repeat, data):
        return

    def OnQueryOrderFail(self, alreadyBuy, itemId, orderId, buyType, repeat, message=None):
        if self.FinishShopQuery():
            return
        print ('OnQueryOrderFail itemId={}').format(itemId)
        repeat += 1
        if repeat >= 10:
            self.HideBuyItemWaiting()
            self.ShowConfirmPop('提示', '查询购买结果失败，请重试')
            return

        def querySuc(data):
            self.OnQueryOrderSuc(alreadyBuy, itemId, orderId, buyType, repeat, data)
            return

        def queryFail():
            self.OnQueryOrderFail(alreadyBuy, itemId, orderId, buyType, repeat)
            return

        def delayQuery():
            self.mBuyTimer = None

            def queryFunc():
                network_proxy.store_buy_item_result(orderId, buyType, querySuc, queryFail)
                print ('store_buy_item_result start orderId={} buyType={}').format(orderId, buyType)
                return

            self.StartShopQuery(queryFunc)
            return

        comp = clientApi.GetEngineCompFactory().CreateGame(clientApi.GetLevelId())
        self.mBuyTimer = comp.AddTimer(1.0, delayQuery)
        return

    def StopBuyTimer(self):
        if not self.mBuyTimer:
            return
        else:
            comp = clientApi.GetEngineCompFactory().CreateGame(clientApi.GetLevelId())
            comp.CancelTimer(self.mBuyTimer)
            self.mBuyTimer = None
            return

    def DoBuyTimer(self):
        self.mBuyTimer = None
        return

    def Destroy(self):
        self.UnListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'OnScriptTickClient', self, self.OnScriptTickClient)
        self.UnListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'OnBackButtonReleaseClientEvent', self, self.OnCloseShop)
        return


def delayQuery_exceptV():
    return


return
