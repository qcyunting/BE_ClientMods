# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
# Embedded file name: mod/client/neteaseSystem/neteaseHotfixClientSystem.py
import mod.client.extraClientApi as clientApi
from mod_log import engine_logger as logger
ClientSystem = clientApi.GetClientSystemCls()

class neteaseHotfixClientSystem(ClientSystem):

    def __init__(self, namespace, systemName):
        ClientSystem.__init__(self, namespace, systemName)
        self.waitLogin = -1
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'OnScriptTickClient', self, self.onScriptTick)
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'UiInitFinished', self, self.onUiInitFinished)
        self.DefineEvent('CallHotfixEvent')
        self.ListenForEvent('NeteaseHotfix', 'GameHotfixSys', 'NewHotfixEvent', self, self.OnNewHotfix)
        self.apply_hotfix_list = []
        logger.info('neteaseHotfixClientSystem load')
        return

    def Destroy(self):
        self.UnListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'OnScriptTickClient', self, self.onScriptTick)
        self.UnListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'UiInitFinished', self, self.onUiInitFinished)
        self.UnListenForEvent('NeteaseHotfix', 'GameHotfixSys', 'NewHotfixEvent', self, self.OnNewHotfix)
        return

    def onScriptTick(self):
        if self.waitLogin >= 0:
            self.waitLogin -= 1
            if self.waitLogin == 0:
                self.requestHotfix()
        return

    def onUiInitFinished(self, data):
        self.waitLogin = 45
        return

    def requestHotfix(self):
        data = self.CreateEventData()
        data['_id'] = clientApi.GetLocalPlayerId()
        data['applyed'] = self.apply_hotfix_list
        self.NotifyToServer('CallHotfixEvent', data)
        logger.info('requestHotfix')
        return

    def OnNewHotfix(self, args):
        file = args['file']
        content = args['content']
        if file in self.apply_hotfix_list:
            logger.info('OnNewHotfix file=%s already in apply_hotfix_list', file)
            return
        logger.info('client hotfix file=%s start', file)
        try:
            module = import_module_from_string(content)
            module.hotfix()
            logger.info('client hotfix file=%s success', file)
        except:
            import traceback
            traceback.print_exc()
            logger.info('client hotfix file=%s fail', file)

        return


def import_module_from_string(string_buff, name='unknown', filename='unknown'):
    import imp
    mod = imp.new_module(name)
    mod.__file__ = '<%s(from string)>' % filename
    exec string_buff in mod.__dict__
    return mod


def requestHotfix_newVersi0n():
    return


return
